export class FuncionarioAduanero {
  nroRegistro: string;
  nombre: string;
}
