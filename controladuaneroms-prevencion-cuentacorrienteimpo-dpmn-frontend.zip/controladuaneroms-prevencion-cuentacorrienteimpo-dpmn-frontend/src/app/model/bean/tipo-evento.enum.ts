export enum TipoEvento {
  RECTIFICACION = "RECTIFICACION",
  NUEVO = "NUEVO",
  ANULACION = "ANULACION"
}
