import { CatalogoItem } from "./catalogo-item";

export class DocIdentidad {
  tipo : CatalogoItem;
  numero : string;
}
