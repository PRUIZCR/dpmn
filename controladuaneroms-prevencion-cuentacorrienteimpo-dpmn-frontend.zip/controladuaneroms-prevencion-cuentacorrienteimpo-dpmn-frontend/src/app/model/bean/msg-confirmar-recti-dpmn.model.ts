export class MsgConfirmarRectiDpmn {
  correlativoEvento: string;
  correlativoDpmn: number;
}
