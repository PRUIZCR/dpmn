import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { TokenAccesoExtranetService } from '../services/token-acceso-extranet.service';
import { TokenAccesoService }from '../services/token-acceso.service';

@Injectable({
  providedIn: 'root'
})
export class AccesoExtranetGuard implements CanActivate {
  
  constructor(private tokenAccesoExtranetService: TokenAccesoExtranetService){
  }
  
  canActivate(): Observable<boolean> | Promise<boolean> | boolean {
    return new Observable<boolean>(obs => {

      this.tokenAccesoExtranetService.obtenerUrlToken().subscribe(
        data => {
          obs.next(true);
        },err => {
          console.log('Error');
          obs.next(false);
        }
      );
      
  });
}
  
}
