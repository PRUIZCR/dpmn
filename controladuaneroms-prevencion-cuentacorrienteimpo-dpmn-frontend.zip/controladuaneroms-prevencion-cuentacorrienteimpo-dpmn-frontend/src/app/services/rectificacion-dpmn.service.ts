import { Inject, Injectable } from '@angular/core';
import { Dpmn } from '../model/domain/dpmn.model';
import { DamSerieDpmn } from '../model/domain/dam-serie-dpmn.model';
import { ArchivoDpmn } from '../model/bean/archivo-dpmn.model';
import { Archivo } from '../model/bean/archivo.model';
import { ChkEstadoEvento } from '../model/bean/chk-estado-evento.model';
import { MsgConfirmarRectiDpmn } from '../model/bean/msg-confirmar-recti-dpmn.model';
import { MsgRectiDpmn } from '../model/bean/msg-recti-dpmn.model';
import { BehaviorSubject, forkJoin, Observable, of, ReplaySubject, throwError } from 'rxjs';
import { ComprobantePago } from '../model/domain/comprobante-pago.model';
import { DataCatalogo } from '../model/common/data-catalogo.model';
import { ConstantesApp } from '../utils/constantes-app';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { IdentificadorDpmn } from '../model/domain/identificador-dpmn.model'
import { catchError, concatMap, delay, map, mergeMap, retryWhen, take, timestamp } from 'rxjs/operators';
import { Respuesta } from '../model/common/Respuesta';
import { Estado } from '../model/common/Estado';
import { TokenAccesoService } from './token-acceso.service';
import { ParamBusqDcl } from '../model/bean/param-busq-dcl.model';
import { AppEndpointConfig, APP_ENDPOINT_CONFIG } from '../utils/app-endpoint-config';
import { PciDetalle } from '../model/bean/pci-detalle';
import { TipoNacionalidad } from '../model/common/tipo-nacionalidad.enum';
import * as _ from 'lodash';
import { TipoEntidadNegocio } from '../model/bean/tipo-entidad-negocio.enum';
import { TipoEvento } from '../model/bean/tipo-evento.enum';
import { AdjuntoDpmn } from '../model/domain/adjunto-dpmn.model';
import { ItemDpmnParaRectificar } from '../model/bean/item-dpmn-para-rectificar.model';

@Injectable()
export class RectificacionDpmnService {

  private readonly maxIntentos : number = 10;

  private identificadorDpmn : IdentificadorDpmn;

  private pasoActualSubject = new BehaviorSubject<number>(1);
  public pasoActual$ = this.pasoActualSubject.asObservable();

  private versionOriginal : number = null;
  private dpmnOriginal: Dpmn = new Dpmn();
  private damSeriesDpmnOriginal : DamSerieDpmn[] = new Array();
  private archivosDpmnOriginal: ArchivoDpmn[]  = new Array();

  private dpmn: Dpmn = new Dpmn();
  private dpmnSubject = new BehaviorSubject<Dpmn>(this.dpmn);
  public dpmn$ = this.dpmnSubject.asObservable();

  private damSeriesDpmn : DamSerieDpmn[] = new Array();
  private damSeriesDpmnSubject = new BehaviorSubject<DamSerieDpmn[]>(new Array());
  public damSeriesDpmn$ = this.damSeriesDpmnSubject.asObservable();

  private archivosDpmn: ArchivoDpmn[]  = new Array();
  private archivosDpmnSubject = new BehaviorSubject<ArchivoDpmn[]>(this.archivosDpmn);
  public archivosDpmn$ = this.archivosDpmnSubject.asObservable();

  private resultRectificacionDpmn : Respuesta<IdentificadorDpmn> = null;
  private resultRectificacionDpmnSubject = new BehaviorSubject<Respuesta<IdentificadorDpmn>>(this.resultRectificacionDpmn);
  public  resultRectificacionDpmn$ = this.resultRectificacionDpmnSubject.asObservable();

  private msgConfirmNewDamSerieDpmnSubject = new BehaviorSubject<String>(null);
  public msgConfirmNewDamSerieDpmn$ = this.msgConfirmNewDamSerieDpmnSubject.asObservable();

  private appEndPointConfig: AppEndpointConfig;

  constructor(private http: HttpClient, private tokenAccesoService: TokenAccesoService,
                @Inject(APP_ENDPOINT_CONFIG) newAppEndPointConfig : AppEndpointConfig) {
      this.appEndPointConfig = newAppEndPointConfig;
  }

  limpiarData() : void {
    this.dpmn = new  Dpmn();
    this.damSeriesDpmn = new Array();
    this.archivosDpmn = new Array();
    this.resultRectificacionDpmn = null;

    this.limpiarDataOriginal();

    this.dpmnSubject.next(this.dpmn);
    this.damSeriesDpmnSubject.next(this.damSeriesDpmn);
    this.archivosDpmnSubject.next(this.archivosDpmn);
    this.resultRectificacionDpmnSubject.next(this.resultRectificacionDpmn);
  }

  putDataOriginal(newDpmn: Dpmn, newDamSeriesDpmn: DamSerieDpmn[], newArchivosDpmn: ArchivoDpmn[], newVersion: number) : void {
    this.identificadorDpmn = new IdentificadorDpmn();
    this.identificadorDpmn.anio = newDpmn.annDpmn;
    this.identificadorDpmn.codAduana = newDpmn.aduana.codDatacat;
    this.identificadorDpmn.correlativo = newDpmn.numCorrelativo;
    this.identificadorDpmn.numero = newDpmn.numDpmn;

    this.dpmnOriginal = JSON.parse(JSON.stringify(newDpmn));
    this.damSeriesDpmnOriginal = JSON.parse(JSON.stringify(newDamSeriesDpmn));
    this.archivosDpmnOriginal = JSON.parse(JSON.stringify(newArchivosDpmn));
    this.versionOriginal = newVersion;
  }

  private limpiarDataOriginal() : void {
    this.dpmnOriginal = new Dpmn();
    this.damSeriesDpmnOriginal = new Array();
    this.archivosDpmn = new Array();
    this.versionOriginal = null;
  }

  putDpmn(newDpmn: Dpmn) : void {
    this.dpmn = newDpmn;
    this.dpmnSubject.next(this.dpmn);
  }

  putNewDamSeriesDpmn(newDamSeriesDpmn : DamSerieDpmn[]) : void {
    this.damSeriesDpmn = newDamSeriesDpmn;
    this.damSeriesDpmnSubject.next(this.damSeriesDpmn);
  }

  putAdjuntosOriginales(adjuntos : ArchivoDpmn[]) : void {
    this.archivosDpmn = adjuntos;
    this.archivosDpmnSubject.next(this.archivosDpmn);
  }

  putDamSeriesDpmn(correComprob : number, newDamSeriesDpmn : DamSerieDpmn[]) : void {

    if ( newDamSeriesDpmn == null ) {
      return;
    }

    var seriesParaAgregar = newDamSeriesDpmn.filter(itemDamSerieDpmn => itemDamSerieDpmn?.cntRetirada > 0 );

    let correSerie = this. obtenerCorreDamSerieDpmn();

    seriesParaAgregar.forEach(serieAdd => {
      serieAdd.numCorreCompDpmn = correComprob;
      serieAdd.numCorrelativo = correSerie;
      this.damSeriesDpmn.push(serieAdd);
      correSerie++;
    });

    this.damSeriesDpmnSubject.next(this.damSeriesDpmn);
    this.enviarMsgConfirmNewDamSeriesDpmn(seriesParaAgregar);
  }

  private enviarMsgConfirmNewDamSeriesDpmn(seriesParaAgregar : DamSerieDpmn[]) : void {

    let numSeries : string[] = new Array();
    let cantidades : string[] = new Array();

    seriesParaAgregar.forEach( ( item : DamSerieDpmn ) => {
      numSeries.push(item.numSerie.toString());
      cantidades.push(item.cntRetirada.toString());
    });

    let descSeries : string = numSeries.toString();
    descSeries = descSeries.replace(",", ", ");

    let desCantidades : string = cantidades.toString();
    desCantidades = desCantidades.replace(",", ", ");

    let mensaje : string = "Se agrega(n) serie(s) " + descSeries + " con " + desCantidades + " unidades físicas a descargar";

    this.msgConfirmNewDamSerieDpmnSubject.next(mensaje);
  }

  limpiarMsgConfirmNewDamSeriesDpmn() : void {
    this.msgConfirmNewDamSerieDpmnSubject.next(null);
  }

  eliminarComprobante(correComprob : number) : void {
    this.dpmn.comprobantePago = this.dpmn?.comprobantePago.filter((item : ComprobantePago) => item.numCorrelativo != correComprob );;
    this.damSeriesDpmn = this.damSeriesDpmn.filter( (item : DamSerieDpmn) => item.numCorreCompDpmn != correComprob  );

    this.dpmnSubject.next(this.dpmn);
    this.damSeriesDpmnSubject.next(this.damSeriesDpmn);
  }

  eliminarDeclaracion(itemDamSerieDpmn : DamSerieDpmn) : void {

      let numCorreComp : number = itemDamSerieDpmn.numCorreCompDpmn;
      let numCorreDcl : number = itemDamSerieDpmn.numCorrelativo;

      if ( this.esUltimaDamDelComprobante( numCorreComp ) ) {
        this.eliminarComprobante(numCorreComp);
        return;
      }

      this.damSeriesDpmn = this.damSeriesDpmn.filter( (item : DamSerieDpmn) => item.numCorrelativo != numCorreDcl );
      this.damSeriesDpmnSubject.next(this.damSeriesDpmn);
  }

  private esUltimaDamDelComprobante ( numCorreComp : number ) : boolean {
    return this.damSeriesDpmn.filter( ( data : DamSerieDpmn ) => data.numCorreCompDpmn == numCorreComp ).length == 1;
  }

  adjuntarArchivo(archivo: File, tipoDocumento: DataCatalogo) : void {

    let correArchivo = this.archivosDpmn.length + 1;

    let archivoDpmn  = new ArchivoDpmn();
    archivoDpmn.id = correArchivo;
    archivoDpmn.codTipoDocumento = tipoDocumento.codDatacat;
    archivoDpmn.desTipoDocumento = tipoDocumento.desDataCat;
    archivoDpmn.nomArchivo = archivo.name;
    archivoDpmn.nomContentType = archivo.type;
    archivoDpmn.fechaRegistro = new Date();
    archivoDpmn.usuarioRegistra = this.tokenAccesoService.login;
    archivoDpmn.origenInvocacion = this.tokenAccesoService.origen;
    archivoDpmn.codAduanaDpmn = this.identificadorDpmn.codAduana;
    archivoDpmn.annioDpmn =  String(this.identificadorDpmn.anio);
    archivoDpmn.numeroDpmn = String(this.identificadorDpmn.numero);
    archivoDpmn.numCorrelativoDpmn = this.identificadorDpmn.correlativo;

    this.convertFile(archivo).subscribe((base64 : string) => {
      archivoDpmn.valArchivoBase64 = base64;
      this.archivosDpmn.push(archivoDpmn);
      this.archivosDpmnSubject.next(this.archivosDpmn);
    });
  }

  eliminarArchivo(idArchivo : number) : void {
    this.archivosDpmn = this.archivosDpmn.filter( ( item : ArchivoDpmn ) => item.id != idArchivo );
    this.archivosDpmnSubject.next(this.archivosDpmn);
  }

  seAgregoNuevosArchivos() : boolean {
    let nuevoArchivo : ArchivoDpmn = this.archivosDpmn.find( ( item : ArchivoDpmn ) => item.codArchivoEcm == null )
    return nuevoArchivo != null;
  }

 private requestGrabarDocumentosECM() :  Observable<AdjuntoDpmn[]> {

  let peticiones : Observable<AdjuntoDpmn>[] = new Array();

  let nuevosArchivosDpmn : ArchivoDpmn[] = this.archivosDpmn.filter( ( item : ArchivoDpmn ) => item.codArchivoEcm == null );

  if ( nuevosArchivosDpmn.length <= 0 ) {
    return of(new Array());
  }

  let url = this.appEndPointConfig.documentosecm;

  nuevosArchivosDpmn.forEach( ( item : ArchivoDpmn ) => {

    let archivo : Archivo = new Archivo();
    archivo.nomArchivo = item.nomArchivo;
    archivo.nomContentType = item.nomContentType;
    archivo.valArchivoBase64 = item.valArchivoBase64;

    let obs : Observable<AdjuntoDpmn> = this.http.post<Archivo>(url, archivo).pipe(
      map ( ( newArchivo : Archivo ) => {
        let respuesta : AdjuntoDpmn = new AdjuntoDpmn();
        respuesta.codArchivoEcm = newArchivo.codArchivoECM;
        respuesta.codTipoDocumento = item.codTipoDocumento;
        respuesta.desTipoDocumento = item.desTipoDocumento;
        respuesta.indEliminado = false;
        respuesta.nomArchivo = newArchivo.nomArchivo;
        respuesta.nomContentType = newArchivo.nomContentType;
        respuesta.numCorrelativoDpmn = item.numCorrelativoDpmn;
        return respuesta;
      }),
      retryWhen(error =>
        error.pipe(
          concatMap((error, count) => {
            if (count < 3) {
              return of(error);
            }
            return throwError(error);
          }),
          delay(5000)
        )
      )
    );

    peticiones.push(obs);
  });

  return forkJoin(peticiones);
 }

  private requestHttpGrabarEventos(eventos : MsgRectiDpmn[]) : Observable<any>[] {
      let url = this.appEndPointConfig.publicarRectificacion;
      let respuesta : Observable<any>[] = new Array();

      eventos.forEach( ( item : MsgRectiDpmn ) => {
        let peticion = this.http.post(url, item).pipe(
          retryWhen(error =>
            error.pipe(
              concatMap((error, count) => {
                if (count < 3) {
                  return of(error);
                }
                return throwError(error);
              }),
              delay(5000)
            )
          )
        );
        respuesta.push(peticion);
      });
      return respuesta;
  }

  private requestCheckEstadoEventos(chkEstadoEvento : ChkEstadoEvento) : Observable<any> {

    return this.http.post(this.appEndPointConfig.checkEstadoEventos, chkEstadoEvento).pipe(
      retryWhen(error =>
        error.pipe(
          concatMap((error, count) => {
            if (count < this.maxIntentos) {
              return of(error);
            }
            return throwError(error);
          }),
          delay(5000)
        )
      )
    );

  }

  private requestConfirmarRectificacion( mensaje : MsgConfirmarRectiDpmn) : Observable<any> {

    return this.http.post( this.appEndPointConfig.confirmaRectificacion, mensaje ).pipe(
      retryWhen(error =>
        error.pipe(
          concatMap((error, count) => {
            if (count < 3) {
              return of(error);
            }
            return throwError(error);
          }),
          delay(5000)
        )
      )
    );

  }

  private requestCancelarRectificacion( correlativoEvento : string ) : Observable<any> {
    return this.http.post( this.appEndPointConfig.cancelaRectificacion, correlativoEvento ).pipe(
      retryWhen(error =>
        error.pipe(
          concatMap((error, count) => {
            if (count < 3) {
              return of(error);
            }
            return throwError(error);
          }),
          delay(5000)
        )
      )
    );

  }


  private completarDatosFaltantesEventosRecti( eventosRecti : MsgRectiDpmn[] ) : void {
    let contador : number = 0;
    let uuid : string = this.generateUUID();

    eventosRecti.forEach( ( item : MsgRectiDpmn ) => {
      item.uuid = uuid;
      item.correlativoDpmn = this.dpmn.numCorrelativo;
      item.secuencia = ++contador;
      item.version = this.versionOriginal;
    });
  }

  private generateUUID() : string  {
    var dt = new Date().getTime();
      var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
          var r = (dt + Math.random()*16)%16 | 0;
          dt = Math.floor(dt/16);
          return (c=='x' ? r :(r&0x3|0x8)).toString(16);
      });
      return uuid;
  }

  rectificar(eventosRectificacion : MsgRectiDpmn[]) : void {

    this.resultRectificacionDpmn = Respuesta.create(null, Estado.LOADING);
    this.resultRectificacionDpmnSubject.next(this.resultRectificacionDpmn);

    of(eventosRectificacion).pipe(
      mergeMap( () =>  {
        return this.requestGrabarDocumentosECM();
      }, 3),
      map( ( respuesta : AdjuntoDpmn[] ) => {
        this.completarCambiosAdjuntosDpmnNuevos(respuesta, eventosRectificacion);
        this.completarDatosFaltantesEventosRecti(eventosRectificacion);
        return eventosRectificacion;
      }),
      mergeMap ( ( eventos : MsgRectiDpmn[] ) => {
        return forkJoin(this.requestHttpGrabarEventos(eventos)).pipe( map( () => {
          let checkEstadoEvento : ChkEstadoEvento = new ChkEstadoEvento();
          checkEstadoEvento.anulado = false;
          checkEstadoEvento.procesado = false;
          checkEstadoEvento.cantidad = eventos.length;
          checkEstadoEvento.correlativo = eventos[0].uuid;
          return checkEstadoEvento;
        }));
      }, 5),
      concatMap( ( checkEstadoEvento : ChkEstadoEvento ) => this.requestCheckEstadoEventos(checkEstadoEvento).pipe(
        map( () => {
          let mensaje = new MsgConfirmarRectiDpmn();
          mensaje.correlativoDpmn = this.dpmn.numCorrelativo;
          mensaje.correlativoEvento = checkEstadoEvento.correlativo;

          return { "msgConfirmarRectiDpmn": mensaje, "checkEstadoEvento": checkEstadoEvento };
        })
       ) ),
       concatMap( ( data : any ) => this.requestConfirmarRectificacion( data.msgConfirmarRectiDpmn ).pipe(
         map( () => {
            let checkEstadoEvento : ChkEstadoEvento = data.checkEstadoEvento as ChkEstadoEvento;
            checkEstadoEvento.procesado = true;
            return checkEstadoEvento;
          } )
       ) ),
       concatMap( ( checkEstadoEvento : ChkEstadoEvento ) => this.requestCheckEstadoEventos(checkEstadoEvento) ),
       catchError((error: HttpErrorResponse) => {
        console.error(error);
        this.resultRectificacionDpmn = Respuesta.create(this.identificadorDpmn, Estado.ERROR);
        this.resultRectificacionDpmn.mensajes = Respuesta.obtenerMensajes(error);
        this.resultRectificacionDpmnSubject.next(this.resultRectificacionDpmn);
        return this.requestCancelarRectificacion(eventosRectificacion[0].uuid);
      })
    ).subscribe( () => {

      if ( this.resultRectificacionDpmn.estado == Estado.ERROR ) {
        return;
      }

      this.resultRectificacionDpmn = Respuesta.create(this.identificadorDpmn, Estado.SUCCESS);
      this.resultRectificacionDpmnSubject.next(this.resultRectificacionDpmn);
    });

  }


  validarGrabacionDpmn() : string[] {
    let respuesta : string[] = new Array();

    if ( this.faltaIngresarDeclaracionComprobante() ) {
      respuesta.push("Debe ingresar por lo menos una serie de declaración de importación y un comprobantes de pago");
    }

    if ( this.noTieneArchivosAdjuntos() ) {
      respuesta.push("Debe adjuntar por lo menos un archivo");
    }

    if ( this.faltaIngresarPlacaCarreta() ) {
      respuesta.push("Falta ingresar la placa de la carreta o no debe ingresar el país placa carreta");
    }

    if ( this.faltaIngresarPaisPlacaCarreta() ) {
      respuesta.push("Falta ingresar el país de la placa carreta o no debe ingresar la placa carreta");
    }

    return respuesta;
  }

  validarTranspNacionalConCartaPorte(): string[] {
    let respuesta : string[] = new Array();

    let compCartaPorte : ComprobantePago = this.dpmn?.comprobantePago?.find((item : ComprobantePago) => item.tipoComprobante.codDatacat == ConstantesApp.COD_TIPO_COMP_CARTA_PORTE);
    let existeCompCartaPorte = compCartaPorte != null;
    let esNacional = this.dpmn?.empresaTransporte?.tipoNacionalidad?.codDatacat == TipoNacionalidad.NACIONAL;

    if ( existeCompCartaPorte && esNacional ) {
      respuesta.push("El transportista nacional no puede registrar comprobantes tipo carta porte");
    }

    return respuesta;
  }

  ciudadOrigenIgual(codCiudadOrigen : string) : boolean {
    if ( codCiudadOrigen == null ) {
      return false;
    }

    let codigoCiudadOrigen = this.dpmn?.datoComplementario?.ubigeoOrigen?.codUbigeo;

    return codigoCiudadOrigen == codCiudadOrigen;
  }

  private noTieneArchivosAdjuntos() : boolean {
    return this.archivosDpmn == null || this.archivosDpmn.length <= 0;
  }

  private tienePaisPlacaCarreta() : boolean {
    let paisPlacaCarreta = this.dpmn?.empresaTransporte?.paisPlacaCarreta?.codDatacat;
    return paisPlacaCarreta != null && paisPlacaCarreta.trim().length > 0;
  }

  private tienePlacaCarreta() : boolean {
    let nomPlaca = this.dpmn?.empresaTransporte?.nomPlacaCarreta;
    return nomPlaca != null && nomPlaca.trim().length > 0;
  }

  private faltaIngresarPlacaCarreta() : boolean {
    return this.tienePaisPlacaCarreta() && !this.tienePlacaCarreta();
  }

  private faltaIngresarPaisPlacaCarreta() : boolean {
    return !this.tienePaisPlacaCarreta() && this.tienePlacaCarreta();
  }

  private faltaIngresarDeclaracionComprobante() : boolean {
      let numComprobantes = this.dpmn?.comprobantePago?.length;
      let noHayComprobantes =  numComprobantes == null || numComprobantes <= 0;

      let numDclSeriesDpmn = this.damSeriesDpmn?.length;
      let noHayDclSeriesDpmn = numDclSeriesDpmn == null || numDclSeriesDpmn <= 0;

      return noHayComprobantes || noHayDclSeriesDpmn;
  }

  colocarPasoActual(numeroPaso : number) : void {
    this.pasoActualSubject.next(numeroPaso);
  }

  private obtenerCorreDamSerieDpmn() : number {
    if ( this.damSeriesDpmn == null || this.damSeriesDpmn.length <= 0 ) {
      return 1;
    }

    return Math.max.apply(Math, this.damSeriesDpmn.map( (itDamSerieDpmn) => itDamSerieDpmn.numCorrelativo)) + 1;
  }

  private convertFile(file : File) : Observable<string> {
    const result = new ReplaySubject<string>(1);
    const reader = new FileReader();
    reader.readAsBinaryString(file);
    reader.onload = (event) => result.next(btoa(event.target.result.toString()));
    return result;
  }

  declaracionEstaRegistrada(paramBusqDcl: ParamBusqDcl) : boolean {

    let damEncontrada : DamSerieDpmn = this.damSeriesDpmn.find( ( item : DamSerieDpmn) => {
      let mismaAduana : boolean = item.aduanaDam?.codDatacat ==  paramBusqDcl?.codAduana;
      let mismoRegimen : boolean = item.regimenDam?.codDatacat == paramBusqDcl?.codRegimen;
      let mismoNumero : boolean = item.numDam ==  Number.parseInt(paramBusqDcl?.numero);
      let mismoAnio : boolean = item.annDam ==  Number.parseInt(paramBusqDcl?.anio);

      return mismaAduana && mismoRegimen && mismoNumero && mismoAnio;
    });

    return damEncontrada != null;
  }

  descargarFicharResumen() : Observable<any> {
    let urlFichaQR = this.urlFichaResumenQr;
    return this.http.get(urlFichaQR, {responseType: 'blob' as 'json'});
  }

  private completarDpmnEnSeriesDAM() {
    this.damSeriesDpmn.forEach((item : DamSerieDpmn) => {
      item.numCorreDpmn = this.identificadorDpmn.correlativo;
    });
  }

  generarListaCambios() : MsgRectiDpmn[] {
    let data : MsgRectiDpmn[] =  new Array();

    this.completarDpmnEnSeriesDAM();

    let cambiosEnDpmn : MsgRectiDpmn = this.encontrarCambiosEnDpmn();
    let huboCambiosEnDpmn = !_.isEmpty(cambiosEnDpmn);

    if ( huboCambiosEnDpmn ) {
      data.push(cambiosEnDpmn);
    }

    this.createMsgRectiDamSeriesDpmn().forEach(( item : MsgRectiDpmn )  => data.push(item));
    this.encontrarAdjuntosDpmnEliminados(data);

    return data;
  }


  copiarSaldoEnSeriesDpmnOriginal(lstDamSeriesDpmn : DamSerieDpmn[]) : void {

    let damSeriesDpmnFaltantes : DamSerieDpmn[] = this.damSeriesDpmnOriginal.filter( ( item : DamSerieDpmn ) => item.cntSaldo == null );

    if ( damSeriesDpmnFaltantes.length <= 0 ) {
      return;
    }

    damSeriesDpmnFaltantes.forEach(  ( damSerieDpmnFaltante : DamSerieDpmn ) => {

      let damSerieDpmn : DamSerieDpmn = lstDamSeriesDpmn.find( ( item : DamSerieDpmn ) => item.aduanaDam.codDatacat == damSerieDpmnFaltante.aduanaDam.codDatacat &&
                                                        item.regimenDam.codDatacat == damSerieDpmnFaltante.regimenDam.codDatacat &&
                                                        item.annDam == damSerieDpmnFaltante.annDam &&
                                                        item.numDam == damSerieDpmnFaltante.numDam &&
                                                        item.numSerie == damSerieDpmnFaltante.numSerie);

      damSerieDpmnFaltante.cntSaldo = damSerieDpmn.cntSaldo;
      damSerieDpmnFaltante.numSecDescarga = damSerieDpmn.numSecDescarga;

    } );



  }

  private encontrarCambiosEnDpmn() : MsgRectiDpmn {
    let data : MsgRectiDpmn = new MsgRectiDpmn();

    let pkNegocio : Dpmn = new Dpmn();
    pkNegocio.numCorrelativo = this.dpmnOriginal.numCorrelativo;

    let diffDpmn : Dpmn = this.buscarDiferencias( this.dpmnOriginal, this.dpmn );
    diffDpmn = this.removeEmptyProperties(diffDpmn);

    if ( diffDpmn.comprobantePago != null ) {
      diffDpmn.comprobantePago = this.dpmn.comprobantePago;
    }

    if ( _.isEmpty(diffDpmn) ) {
      return data;
    }

    data.jsonPkNegocio = JSON.stringify(pkNegocio);
    data.jsonData = JSON.stringify(diffDpmn);
    data.tipoEntidadNegocio = TipoEntidadNegocio.DPMNS;
    data.tipoEvento = TipoEvento.RECTIFICACION;
    data.usuario = this.tokenAccesoService.login;

    return data;
  }

  private createMsgRectiDamSeriesDpmn() : MsgRectiDpmn[] {
    let respuesta : MsgRectiDpmn[] = new Array();

    if ( this.noHayCambioDamSeriesDpmn() ) {
      return respuesta;
    }

    this.encontrarCambiosDamSeriesDpmnRectificadas(respuesta);
    this.encontrarCambiosDamSeriesDpmnEliminadas(respuesta);
    this.encontrarCambiosDamSeriesDpmnNuevas(respuesta);

    return respuesta;
  }

  private noHayCambioDamSeriesDpmn() : boolean  {

    let diffDamSeriesDpmn : DamSerieDpmn[] = this.buscarDiferencias( this.damSeriesDpmnOriginal, this.damSeriesDpmn );
    diffDamSeriesDpmn = this.removeEmptyProperties(diffDamSeriesDpmn);

    if ( _.isEmpty(diffDamSeriesDpmn) == null ) {
      return true;
    }

    return false;
  }

  private encontrarCambiosDamSeriesDpmnRectificadas(respuesta : MsgRectiDpmn[]) : void {

    let damSeriesDpmnModificadas : DamSerieDpmn[] = this.damSeriesDpmn.filter( ( item: DamSerieDpmn ) => {
      let damSerieDpmnOriginal = this.buscarDamSerieDpmnOriginal(item);
      return damSerieDpmnOriginal != null;
    });

    damSeriesDpmnModificadas.forEach( ( item : DamSerieDpmn ) => {
      let itemOriginal : DamSerieDpmn = this.buscarDamSerieDpmnOriginal(item);

      let diffDamSerieDpmn : DamSerieDpmn = this.buscarDiferencias(itemOriginal, item);

      diffDamSerieDpmn.fecRegistro = null;
      diffDamSerieDpmn.indEliminado = null;
      diffDamSerieDpmn.auditoria = null;
      diffDamSerieDpmn = this.removeEmptyProperties(diffDamSerieDpmn);

      if ( _.isEmpty(diffDamSerieDpmn) ) {
        return;
      }

      let msgRectiDpmn : MsgRectiDpmn = new MsgRectiDpmn();

      let pkNegocio : DamSerieDpmn = new DamSerieDpmn();
      pkNegocio.numCorrelativo = item.numCorrelativo;
      pkNegocio.numCorreCompDpmn = item.numCorreCompDpmn;
      pkNegocio.numCorreDpmn = this.dpmnOriginal.numCorrelativo;

      msgRectiDpmn.jsonData = JSON.stringify(diffDamSerieDpmn);
      msgRectiDpmn.jsonPkNegocio = JSON.stringify(pkNegocio);
      msgRectiDpmn.tipoEntidadNegocio = TipoEntidadNegocio.DAM_SERIES_DPMN;
      msgRectiDpmn.tipoEvento = TipoEvento.RECTIFICACION;
      msgRectiDpmn.usuario = this.tokenAccesoService.login;

      respuesta.push(msgRectiDpmn);
    });

  }

  private encontrarCambiosDamSeriesDpmnEliminadas(respuesta : MsgRectiDpmn[]) : void {

    let damSeriesDpmnEliminadas = this.damSeriesDpmnOriginal.filter( ( itemOri : DamSerieDpmn ) => {
      let damSerieDpmnModif = this.damSeriesDpmn.find( ( itemModif : DamSerieDpmn ) => itemModif.numCorrelativo == itemOri.numCorrelativo && itemModif.numCorreCompDpmn == itemOri.numCorreCompDpmn );
      return damSerieDpmnModif == null;
    });

    damSeriesDpmnEliminadas.forEach( ( item : DamSerieDpmn ) => {

      let msgRectiDpmn : MsgRectiDpmn = new MsgRectiDpmn();

      let pkNegocio : DamSerieDpmn = new DamSerieDpmn();
      pkNegocio.numCorrelativo = item.numCorrelativo;
      pkNegocio.numCorreCompDpmn = item.numCorreCompDpmn;
      pkNegocio.numCorreDpmn = this.dpmnOriginal.numCorrelativo;

      let dataModif : DamSerieDpmn = new DamSerieDpmn();
      dataModif.indEliminado = true;

      msgRectiDpmn.jsonData = JSON.stringify(dataModif);
      msgRectiDpmn.jsonPkNegocio = JSON.stringify(pkNegocio);
      msgRectiDpmn.tipoEntidadNegocio = TipoEntidadNegocio.DAM_SERIES_DPMN;
      msgRectiDpmn.tipoEvento = TipoEvento.ANULACION;
      msgRectiDpmn.usuario = this.tokenAccesoService.login;

      respuesta.push(msgRectiDpmn);
    });

  }

  private encontrarCambiosDamSeriesDpmnNuevas(respuesta : MsgRectiDpmn[]) : void {
    let damSeriesDpmnNuevas = this.damSeriesDpmn.filter( ( item : DamSerieDpmn ) => {
      let damSerieDpmnOriginal = this.damSeriesDpmnOriginal.find( (itemOri : DamSerieDpmn) => itemOri.numCorreCompDpmn == item.numCorreCompDpmn && itemOri.numCorrelativo == item.numCorrelativo );
      return damSerieDpmnOriginal == null;
    });

    damSeriesDpmnNuevas.forEach( ( item : DamSerieDpmn ) => {

      let msgRectiDpmn : MsgRectiDpmn = new MsgRectiDpmn();

      let pkNegocio : DamSerieDpmn = new DamSerieDpmn();
      pkNegocio.numCorrelativo = item.numCorrelativo;
      pkNegocio.numCorreCompDpmn = item.numCorreCompDpmn;
      pkNegocio.numCorreDpmn = this.dpmnOriginal.numCorrelativo;

      msgRectiDpmn.jsonData = JSON.stringify(item);
      msgRectiDpmn.jsonPkNegocio = JSON.stringify(pkNegocio);
      msgRectiDpmn.tipoEntidadNegocio = TipoEntidadNegocio.DAM_SERIES_DPMN;
      msgRectiDpmn.tipoEvento = TipoEvento.NUEVO;
      msgRectiDpmn.usuario = this.tokenAccesoService.login;

      respuesta.push(msgRectiDpmn);
    });

  }

  private encontrarAdjuntosDpmnEliminados(respuesta : MsgRectiDpmn[]) : void {
    let archivosEliminados : ArchivoDpmn[] = this.archivosDpmnOriginal.filter( ( item : ArchivoDpmn ) => {
      let archivoRecti = this.archivosDpmn.find( (itemRecti : ArchivoDpmn) => itemRecti.codArchivoEcm == item.codArchivoEcm)
      return archivoRecti == null;
    });

    archivosEliminados.forEach( ( item : ArchivoDpmn ) => {

      let pkAdjunto : AdjuntoDpmn = new AdjuntoDpmn();
      let dataAdjunto : AdjuntoDpmn = new AdjuntoDpmn();

      let msgRectiDpmn : MsgRectiDpmn = new MsgRectiDpmn();

      pkAdjunto.codArchivoEcm = item.codArchivoEcm;
      dataAdjunto.indEliminado = true;

      msgRectiDpmn.jsonData = JSON.stringify(dataAdjunto);
      msgRectiDpmn.jsonPkNegocio = JSON.stringify(pkAdjunto);
      msgRectiDpmn.tipoEntidadNegocio = TipoEntidadNegocio.ADJUNTOS_DPMN;
      msgRectiDpmn.tipoEvento = TipoEvento.ANULACION;
      msgRectiDpmn.usuario = this.tokenAccesoService.login;

      respuesta.push(msgRectiDpmn);
    });

  }

  private completarCambiosAdjuntosDpmnNuevos( adjuntosDpmnNuevos : AdjuntoDpmn[], respuesta : MsgRectiDpmn[] ) : void {

    adjuntosDpmnNuevos.forEach( (item : AdjuntoDpmn) => {

      let msgRectiDpmn : MsgRectiDpmn = new MsgRectiDpmn();

      let pkAdjunto : AdjuntoDpmn = new AdjuntoDpmn();
      pkAdjunto.codArchivoEcm = item.codArchivoEcm;

      item.numCorrelativoDpmn = this.identificadorDpmn.correlativo;
      item.indEliminado = false;

      msgRectiDpmn.jsonData = JSON.stringify(item);
      msgRectiDpmn.jsonPkNegocio = JSON.stringify(pkAdjunto);
      msgRectiDpmn.tipoEntidadNegocio = TipoEntidadNegocio.ADJUNTOS_DPMN;
      msgRectiDpmn.tipoEvento = TipoEvento.NUEVO;
      msgRectiDpmn.usuario = this.tokenAccesoService.login;

      respuesta.push(msgRectiDpmn);
    });

  }

  private buscarDamSerieDpmnOriginal( item : DamSerieDpmn ) : DamSerieDpmn {
    return this.damSeriesDpmnOriginal.find( ( itemOriginal : DamSerieDpmn ) => itemOriginal.numCorrelativo == item.numCorrelativo && itemOriginal.numCorreCompDpmn ==  item.numCorreCompDpmn );
  }


  private buscarDiferencias(origObj : any, newObj : any) : any {
    function changes(newObj, origObj) {
      let arrayIndexCounter = 0
      return _.transform(newObj, function (result, value, key) {
        if (!_.isEqual(value, origObj[key])) {
          let resultKey = _.isArray(origObj) ? arrayIndexCounter++ : key
          result[resultKey] = (_.isObject(value) && _.isObject(origObj[key])) ? changes(value, origObj[key]) : value
        }
      });
    }
    return changes(newObj, origObj);
  }

  private removeEmptyProperties(obj : any) {
    if ( _.isArray(obj) ) {
      return obj
      .map(v => (_.isObject(v)) ? this.removeEmptyProperties(v) : v)
      .filter(v => !(_.isEmpty(v)));
    } else {
      return Object.entries(obj)
      .map(([k, v]) => [k, _.isObject(v) ? this.removeEmptyProperties(v) : v])
      .reduce((a, [k, v]) => ( ( _.isEmpty(v) && !(_.isFinite(v)) ) ? a : (a[k]=v, a)), {});
    }
  }

  get urlFichaResumenQr() : string {
    let correlativo = this.identificadorDpmn.correlativo;
    return this.appEndPointConfig.getFichaResumenQr(correlativo);
  }

  get numeroDpmnGenerado() : string {

    if ( this.identificadorDpmn == null ) {
      return null;
    }

    return this.identificadorDpmn?.codAduana + "-" +
            this.identificadorDpmn?.anio + "-" +
            this.identificadorDpmn?.numero;
  }

  setControlDpmn(control: string) {
    this.dpmn.codVariableControl = control;
  }

      /**
     *
     * @author rcontreras
     * @param damSeriesDpmnOriginal - Series de la DAM asociadas a la DPMN Original
     * @param damSerieDpmnRecti - Series de la DAM asociados a la DPMN rectificada
     * @returns
     */
     buscarDamSeriesParaValidarSaldos() : DamSerieDpmn[] {

      let damSeriesDpmnOriginal: DamSerieDpmn[] = _.cloneDeep( this.damSeriesDpmnOriginal );
      let damSerieDpmnRecti: DamSerieDpmn[] = _.cloneDeep( this.damSeriesDpmn );

      let resultado : DamSerieDpmn[] = new Array();

      let damSeriesDpmnComunes : DamSerieDpmn[] = this.findDamSeriesDpmnComunes( damSeriesDpmnOriginal, damSerieDpmnRecti );

      damSeriesDpmnComunes.forEach( ( item : DamSerieDpmn ) => {

        let damSerieDpmnOriginal : DamSerieDpmn = this.buscarDamSerieDpmn( item, damSeriesDpmnOriginal );

        let superaCantidadInicial : boolean =  item.cntRetirada > damSerieDpmnOriginal.cntRetirada;

        if ( superaCantidadInicial ) {
          item.cntRetirada = item.cntRetirada - damSerieDpmnOriginal.cntRetirada;
          resultado.push(item);
        }

      });

      let damSeriesDpmnNuevas : DamSerieDpmn[] = this.findDamSeriesDpmnNuevas( damSeriesDpmnOriginal, damSerieDpmnRecti );

      resultado.push(...damSeriesDpmnNuevas);

      return resultado;
    }

    private findDamSeriesDpmnNuevas( damSeriesDpmnOriginal: DamSerieDpmn[], damSerieDpmnRecti: DamSerieDpmn[] ) : DamSerieDpmn[] {
      return damSerieDpmnRecti.filter( ( itemRecti: DamSerieDpmn ) => this.buscarDamSerieDpmn( itemRecti, damSeriesDpmnOriginal ) == null );
    }

    private findDamSeriesDpmnComunes( damSeriesDpmnOriginal: DamSerieDpmn[], damSerieDpmnRecti: DamSerieDpmn[] ) : DamSerieDpmn[] {
      return damSerieDpmnRecti.filter( ( itemRecti: DamSerieDpmn ) => this.buscarDamSerieDpmn( itemRecti, damSeriesDpmnOriginal ) != null );
    }

    private buscarDamSerieDpmn( damSerieDpmnBusq : DamSerieDpmn, damSeriesDpmn: DamSerieDpmn[] ) : DamSerieDpmn {
      return damSeriesDpmn.find( ( item : DamSerieDpmn ) => this.isMismoKeyDamSerieDpmn(item, damSerieDpmnBusq) );
    }

    private isMismoKeyDamSerieDpmn( obj1: DamSerieDpmn, obj2: DamSerieDpmn ) : boolean {
      return obj1?.aduanaDam?.codDatacat == obj2?.aduanaDam?.codDatacat &&
      obj1?.annDam == obj2?.annDam &&
      obj1?.regimenDam?.codDatacat == obj2?.regimenDam?.codDatacat &&
      obj1?.numDam == obj2?.numDam &&
      obj1?.numSerie == obj2?.numSerie;
    }


}
