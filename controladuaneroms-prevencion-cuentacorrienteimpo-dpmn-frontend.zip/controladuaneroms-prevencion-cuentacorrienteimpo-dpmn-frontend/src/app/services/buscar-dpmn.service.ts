import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Dpmn } from '../model/domain/dpmn.model'
import { APP_ENDPOINT_CONFIG, AppEndpointConfig } from '../utils/app-endpoint-config';
import { DamSerieDpmn } from '../model/domain/dam-serie-dpmn.model';
import { AdjuntoDpmn } from '../model/domain/adjunto-dpmn.model';
import { map } from 'rxjs/operators';
import { ComprobantePago } from '../model/domain/comprobante-pago.model';
import { ConstantesApp } from '../utils/constantes-app';
import { GuiaRemision } from '../model/domain/guia-remision.model';
import { CartaPorte } from '../model/domain/carta-porte.model';
import { TipoComprobante } from '../model/common/tipo-comprobante.enum';
import { ArchivoDpmn } from '../model/bean/archivo-dpmn.model';

@Injectable()
export class BuscarDpmnService {

  constructor( private http: HttpClient,
                @Inject(APP_ENDPOINT_CONFIG) private appEndPointConfig : AppEndpointConfig ) { }

  buscar(correlativo: number) : Observable<Dpmn> {
    let url : string = this.appEndPointConfig.dpmns + "/" + correlativo;
    return this.http.get<Dpmn>(url).pipe(map( (data : any) => {
       let resultado : Dpmn = data;

       let infoComp :  ComprobantePago[] = []

       data.comprobantePago.filter( dataComp => dataComp.indEliminado == false ).forEach( dataComp => {
        infoComp.push( this.buildComprobante(dataComp) );
       });

       resultado.comprobantePago = infoComp;

       return resultado;
    }));
  }

  buscarDamSeries(correlativo: number) : Observable<DamSerieDpmn[]>  {
    let url : string = this.appEndPointConfig.dpmns + "/" + correlativo + "/damseriesdpmn";
    return this.http.get<DamSerieDpmn[]>(url).pipe( map( ( lstDamSeriesDpmn :  DamSerieDpmn[] ) => {
      return lstDamSeriesDpmn.filter( ( item : DamSerieDpmn ) => item.indEliminado == false );
    }));
  }

  buscarAdjuntos(correlativo: number) : Observable<ArchivoDpmn[]>  {
    let url : string = this.appEndPointConfig.dpmns + "/" + correlativo + "/adjuntosdpmn";
    return this.http.get<ArchivoDpmn[]>(url).pipe(map((data : any[]) => {

      let resultado : ArchivoDpmn[] = new Array();
      let secuencia : number = 0;

      data.filter( ( item : AdjuntoDpmn ) => item.indEliminado == false ).forEach( (adjunto : AdjuntoDpmn) => {
        let archivo : ArchivoDpmn = new ArchivoDpmn();
        archivo.id = secuencia++;
        archivo.numCorrelativoDpmn = adjunto.numCorrelativoDpmn;
        archivo.codTipoDocumento = adjunto.codTipoDocumento;
        archivo.desTipoDocumento = adjunto.desTipoDocumento;
        archivo.nomArchivo = adjunto.nomArchivo;
        archivo.nomContentType = adjunto.nomContentType;
        archivo.fechaRegistro = adjunto.fecRegistro;
        archivo.codArchivoEcm = adjunto.codArchivoEcm;
        resultado.push(archivo);
      });

      return resultado;
    }));
  }

  buscarVersion(correlativo: number) : Observable<number>  {
    let url : string = this.appEndPointConfig.dpmns + "/" + correlativo + "/version";
    return this.http.get<number>(url);
  }

  descargarAdjunto(idEcm : string) : Observable<Blob> {
    let url : string = this.appEndPointConfig.archivosadjuntodpmn + "/" + idEcm
    return this.http.get(url,{responseType: 'blob'})
  }

  private buildComprobante( dataComp : any ) : ComprobantePago {

    let resultado : ComprobantePago = dataComp;

    switch ( dataComp?.tipoComprobante?.codDatacat ) {
      case ConstantesApp.COD_TIPO_COMP_GUIA_REMISION :
        return this.buildGuiaRemision(dataComp);
      case ConstantesApp.COD_TIPO_COMP_CARTA_PORTE :
        return this.buildCartaPorte(dataComp);
    }

    return resultado;
  }

  private buildGuiaRemision( dataComp : any ) : GuiaRemision {
    let guiaRemision : GuiaRemision =  new GuiaRemision();
    guiaRemision.type = TipoComprobante.GUIA_REMISION;

    this.completeCommonPropsDataComp(dataComp, guiaRemision);

    guiaRemision.numSerie = dataComp.numSerie;
    guiaRemision.numGuia = dataComp.numGuia;
    guiaRemision.numRucRemitente = dataComp.numRucRemitente;
    guiaRemision.desRazonSocialRemitente = dataComp.desRazonSocialRemitente;

    return guiaRemision;
  }

  private buildCartaPorte( dataComp : any ) : CartaPorte {
    let cartaPorte : CartaPorte = new CartaPorte();
    cartaPorte.type = TipoComprobante.CARTA_PORTE;

    this.completeCommonPropsDataComp(dataComp, cartaPorte);

    cartaPorte.numCartaPorte = dataComp.numCartaPorte;
    cartaPorte.nomEmpresa = dataComp.nomEmpresa;

    return cartaPorte;
  }

  private completeCommonPropsDataComp( dataCompSource : any, dataCompTarget : ComprobantePago ) {
    dataCompTarget.numCorrelativo = dataCompSource.numCorrelativo;
    dataCompTarget.tipoComprobante = dataCompSource.tipoComprobante;
    dataCompTarget.numRucDestinatario = dataCompSource.numRucDestinatario;
    dataCompTarget.desRazonSocialDestinatario = dataCompSource.desRazonSocialDestinatario;
    dataCompTarget.motivoDeTraslado = dataCompSource.motivoDeTraslado;
    dataCompTarget.ubigeoDestino = dataCompSource.ubigeoDestino;
    dataCompTarget.indEliminado = dataCompSource.indEliminado;
  }

}
