import { Component, OnInit } from '@angular/core';
import { Respuesta } from 'src/app/model/common/Respuesta';
import { TokenAccesoService } from 'src/app/services/token-acceso.service';
import { Estado } from 'src/app/model/common/Estado';
import { ItemDpmnParaRectificar} from 'src/app/model/bean/item-dpmn-para-rectificar.model';
import { BuscarRectiDpmnService } from 'src/app/services/buscar-recti-dpmn.service';
import { BuscarDpmnService } from 'src/app/services/buscar-dpmn.service';
import { MessageService } from 'primeng/api';
import { Router, ActivatedRoute } from '@angular/router';
import { forkJoin, Observable } from 'rxjs';
import { RectificacionDpmnService } from 'src/app/services/rectificacion-dpmn.service';

@Component({
  selector: 'app-lista-dpmn-recti',
  templateUrl: './lista-dpmn-recti.component.html',
  styleUrls: ['./lista-dpmn-recti.component.css'],
  providers: [MessageService, BuscarDpmnService]
})
export class ListaDpmnRectiComponent implements OnInit {
  public rptaListaCtrlDpmns: Respuesta<ItemDpmnParaRectificar[]> = Respuesta.create(null, null);
  public lstDpmns: any[] = new Array();
  usuarioLogin = this.tokenAccesoService.origen;
  coUsuarioRegistroDPMN : String;
  actorRegistro: String;

  public lstDpmnsSelected: any[] = new Array();

  constructor(  private buscarRectiDpmnService : BuscarRectiDpmnService,
                private rectificacionDpmnService : RectificacionDpmnService,
                private buscarDpmnService: BuscarDpmnService,
                private messageService: MessageService,
                private router:Router,
                private activatedRoute: ActivatedRoute,
                private tokenAccesoService: TokenAccesoService) {
                }

  ngOnInit(): void {
    this.cargarDpmns();
  }

  private cargarDpmns() : void {
    this.buscarRectiDpmnService.rptaBusqDcl$.subscribe((resultado : Respuesta<ItemDpmnParaRectificar[]>) =>{
      this.rptaListaCtrlDpmns= resultado;
    }, () => {
      this.configRespuestaConError();
    });
  }

  private configRespuestaConError() : void {
    this.rptaListaCtrlDpmns = Respuesta.create(null, Estado.ERROR);
    this.rptaListaCtrlDpmns.agregarMensaje(1, "Ha ocurrido un error")
  }

  private getObsDataDpmn( correlativo: number ) : Observable<any> {
    return forkJoin({
      dpmn : this.buscarDpmnService.buscar(correlativo),
      damSeriesDpmn: this.buscarDpmnService.buscarDamSeries(correlativo),
      adjuntosDpmn: this.buscarDpmnService.buscarAdjuntos(correlativo),
      versionDpmn: this.buscarDpmnService.buscarVersion(correlativo)
    });
  }

  continuarRectificaDpmn(item : ItemDpmnParaRectificar) : any {
    this.buscarRectiDpmnService.itemDpmn = item;
    console.log(this.buscarRectiDpmnService.itemDpmn);
    this.coUsuarioRegistroDPMN = item.auditoria.codUsuRegis;

    this.actorRegistro = item.actorRegistro.codDatacat;
    let esUsuarioExterno : boolean = this.actorRegistro == "UE";
    if (!esUsuarioExterno){
      this.messageService.add({ key: 'msj' , severity:"warn", summary: 'Mensaje',   detail: 'No puede rectificar una DPMN registrada por el funcionario aduanero'});
      return false;
    }

    let esMismoUsuario : boolean = this.coUsuarioRegistroDPMN == this.tokenAccesoService.login;
    if (!esMismoUsuario){
      this.messageService.add({ key: 'msj', severity:"warn", summary: 'Mensaje',   detail: 'No es posible rectificar una DPMN registrada por otro usuario'});
      return false;
    }

    this.getObsDataDpmn(item.correlativoDpmn).subscribe( data => {
      this.rectificacionDpmnService.putDataOriginal(data.dpmn, data.damSeriesDpmn, data.adjuntosDpmn, data.versionDpmn);
      this.rectificacionDpmnService.putDpmn(data.dpmn);
      this.rectificacionDpmnService.putNewDamSeriesDpmn(data.damSeriesDpmn);
      this.rectificacionDpmnService.putAdjuntosOriginales(data.adjuntosDpmn);
      this.buscarRectiDpmnService.limpiarData();
      this.router.navigate(['../datos-transporte'], { relativeTo: this.activatedRoute });
    });

    return true;
  }

  irPageBusquedaInicial() {
		this.buscarRectiDpmnService.limpiarData();
		this.router.navigate(['../buscar-dpmn'], { relativeTo: this.activatedRoute });
  }

}
