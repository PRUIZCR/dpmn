import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BuscarDpmnComponent } from './components/buscar-dpmn/buscar-dpmn.component'
import { ItRectidpmnAdddclComponent } from './components/it-rectidpmn-adddcl/it-rectidpmn-adddcl.component';
import { ItRectidpmnAdjuntoComponent } from './components/it-rectidpmn-adjunto/it-rectidpmn-adjunto.component';
import { ItRectidpmnDatoscompComponent } from './components/it-rectidpmn-datoscomp/it-rectidpmn-datoscomp.component';
import { ItRectidpmnDatostranspComponent } from './components/it-rectidpmn-datostransp/it-rectidpmn-datostransp.component';
import { ItRectidpmnInicioComponent } from './components/it-rectidpmn-inicio/it-rectidpmn-inicio.component';
import { ListaDpmnRectiComponent } from './components/lista-dpmn-recti/lista-dpmn-recti.component';

const routes: Routes = [
  { path: 'buscar-dpmn', component: BuscarDpmnComponent },
  { path: 'listar-dpmn-recti', component: ListaDpmnRectiComponent },
  {
    path: '', component: ItRectidpmnInicioComponent,
    children: [
      { path: 'datos-transporte', component: ItRectidpmnDatostranspComponent },
      { path: 'comprobantes', component: ItRectidpmnDatoscompComponent },
      { path: 'adjuntar-archivos', component: ItRectidpmnAdjuntoComponent },
      { path: 'add-declaracion', component: ItRectidpmnAdddclComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ItrectificaciondpmnRoutingModule { }
