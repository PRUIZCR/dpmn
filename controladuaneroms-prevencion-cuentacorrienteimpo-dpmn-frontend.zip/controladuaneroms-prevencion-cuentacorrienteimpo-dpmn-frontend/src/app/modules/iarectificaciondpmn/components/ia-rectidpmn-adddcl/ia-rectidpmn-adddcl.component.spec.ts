import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IaRectidpmnAdddclComponent } from './ia-rectidpmn-adddcl.component';

describe('IaRectidpmnAdddclComponent', () => {
  let component: IaRectidpmnAdddclComponent;
  let fixture: ComponentFixture<IaRectidpmnAdddclComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IaRectidpmnAdddclComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IaRectidpmnAdddclComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
