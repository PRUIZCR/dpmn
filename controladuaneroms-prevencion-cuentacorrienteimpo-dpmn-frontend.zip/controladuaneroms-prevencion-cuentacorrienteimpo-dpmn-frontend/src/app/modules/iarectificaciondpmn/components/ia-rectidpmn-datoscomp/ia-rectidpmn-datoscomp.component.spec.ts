import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IaRectidpmnDatoscompComponent } from './ia-rectidpmn-datoscomp.component';

describe('IaRectidpmnDatoscompComponent', () => {
  let component: IaRectidpmnDatoscompComponent;
  let fixture: ComponentFixture<IaRectidpmnDatoscompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IaRectidpmnDatoscompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IaRectidpmnDatoscompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
