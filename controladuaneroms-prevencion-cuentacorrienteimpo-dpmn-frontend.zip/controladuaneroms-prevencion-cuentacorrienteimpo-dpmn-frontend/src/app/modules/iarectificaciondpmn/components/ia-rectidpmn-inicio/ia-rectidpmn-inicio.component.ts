import { ChangeDetectorRef, Component, OnInit} from '@angular/core';
import { RectificacionDpmnService } from 'src/app/services/rectificacion-dpmn.service';

@Component({
  selector: 'app-ia-rectidpmn-inicio',
  templateUrl: './ia-rectidpmn-inicio.component.html',
  styleUrls: ['./ia-rectidpmn-inicio.component.css']
})
export class IaRectidpmnInicioComponent implements OnInit {

  pasoActual : number = 1;

  constructor(private rectificacionDpmnService: RectificacionDpmnService,
              private cdRef:ChangeDetectorRef) { }

  ngOnInit(): void {
    this.rectificacionDpmnService.pasoActual$.subscribe( (numPaso : number) => {
        this.pasoActual = numPaso;
        this.cdRef.detectChanges();
    });
  }
}
