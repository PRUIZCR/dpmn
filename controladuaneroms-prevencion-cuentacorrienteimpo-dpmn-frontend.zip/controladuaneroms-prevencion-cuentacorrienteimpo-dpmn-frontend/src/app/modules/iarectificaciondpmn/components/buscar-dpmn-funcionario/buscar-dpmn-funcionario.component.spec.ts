import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuscarDpmnFuncionarioComponent } from './buscar-dpmn-funcionario.component';

describe('BuscarDpmnFuncionarioComponent', () => {
  let component: BuscarDpmnFuncionarioComponent;
  let fixture: ComponentFixture<BuscarDpmnFuncionarioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuscarDpmnFuncionarioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuscarDpmnFuncionarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
