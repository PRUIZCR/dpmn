import { CargarJsonDirective } from './cargar-json.directive';

describe('CargarJsonDirective', () => {
  it('should create an instance', () => {
    const directive = new CargarJsonDirective(null, null, null);
    expect(directive).toBeTruthy();
  });
});
