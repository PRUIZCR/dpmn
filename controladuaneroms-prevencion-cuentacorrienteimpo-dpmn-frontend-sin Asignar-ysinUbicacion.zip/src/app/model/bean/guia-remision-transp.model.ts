export class GuiaRemisionTransp {
  numeroRuc:string;
  serieComprobante:string;
  tipoComprobante:string;
  numeroComprobante:number;
  respuesta:string;
}
