export const environment = {
  production: false,
  urlBase: 'https://api-test.sunat.gob.pe',
  urlBaseIntranet: 'https://api-intranet.sunat.peru',
  urlComponentPCI: 'http://localhost:4400',
  urlIntegradorComponentPCI: '../pci'
};
