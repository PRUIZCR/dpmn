import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { TokenAccesoService } from './services/token-acceso.service';
import { CargaComponentesService } from './services/carga-componentes.service';
import { UbicacionFuncionarioService } from './services/ubicacion-funcionario.service';
import { RegistroDpmnService } from './services/registro-dpmn.service';
import { UbicacionFuncionario } from './model/bean/ubicacion-funcionario';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'controladuaneroms-prevencion-cuentacorrienteimpo-dpmn-frontend';

  constructor(private activateRoute: ActivatedRoute,
    private router: Router,
    private tokenAccesoService: TokenAccesoService,
    private cargaComponentes: CargaComponentesService,
    private ubicacionFuncionarioService: UbicacionFuncionarioService,
    private registroDpmnService: RegistroDpmnService) { }

  ngOnInit(): void {
    this.activateRoute.queryParams
    .subscribe(params => {
        let hayToken : boolean = params.token != null;
        let hayParamP : boolean = params.p != null;

        if ( hayToken ) {
          this.tokenAccesoService.guardarTokenSession(params.token);
          this.redirectPage(params);
        }

        if ( !hayToken && hayParamP ) {
          this.redirectPage(params);
        }

      }
    );
  }

  private redirectPage(params: any) : void {
    let noHayModulo : boolean = params.modulo == null;

    if ( noHayModulo ) {
      this.router.navigate(['/itregistrodpmn/datos-transporte']);
      return;
    }

    if ( params.modulo == 'itregistrodpmn' ) {      
      this.router.navigate(['/itregistrodpmn/datos-transporte']);      
      return;
    }

    if ( params.modulo == 'iaregistrodpmn' ) {      
      this.router.navigate(['/iaregistrodpmn/listar-control-paso']);
      return;
    }

    if ( params.modulo == 'iaregistrodpmn_linkeo' ) {      
      //DESCOMENTAR
      this.getDatosFuncionario(params)      
      //this.cargaComponentes.guardarNumCorrePci(params.numCorrePci); //COMENTAR
      //this.cargaComponentes.cargarConfirmacionDeDpmn(null); //COMENTAR      
    }

  }

  //DESCOMENTAR
   getDatosFuncionario(params: Params){
    let nroRegistro: string = this.tokenAccesoService.nroRegistro as string;

    this.ubicacionFuncionarioService.buscar(nroRegistro).subscribe((ubicacion: UbicacionFuncionario) => {
      if(ubicacion == undefined || ubicacion == null)
        return;

      this.registroDpmnService.datosFuncionario = ubicacion;
      this.cargaComponentes.guardarNumCorrePci(params.numCorrePci);
      this.cargaComponentes.cargarConfirmacionDeDpmn(ubicacion);

    });
  } 

}
