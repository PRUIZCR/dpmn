import { Injectable } from '@angular/core';
import { ConstantesApp } from '../utils/constantes-app';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { PciDetalle } from '../model/domain/pcidetalle.model';
import { environment } from '../../environments/environment';
import { UbicacionFuncionario } from '../model/bean/ubicacion-funcionario';
import { RegistroDpmnService } from './registro-dpmn.service';

@Injectable({
  providedIn: 'root'
})
export class CargaComponentesService {

  constructor(private http: HttpClient,
    private router: Router,
     private registroDpmnService: RegistroDpmnService ) { }

  guardarNumCorrePci(numCorrePci: string) : void{
    sessionStorage.setItem(ConstantesApp.KEY_SESSION_NUMCORR_PCI, numCorrePci);
  }

  get numCorrePci() : string {
    return sessionStorage.getItem(ConstantesApp.KEY_SESSION_NUMCORR_PCI) as string;
  }

  async cargarConfirmacionDeDpmn(ubicacion: UbicacionFuncionario) {
    let numCorrePci = this.numCorrePci;    
    let pci = await this.getDataPciSynchronous(numCorrePci) as PciDetalle[];    
    sessionStorage.setItem("vieneDesdePCI", ConstantesApp.VIENE_DESDE_PCI); //Yes/No
    sessionStorage.setItem("numeroDeControlPaso", pci[0].controlPaso);
    sessionStorage.setItem("paisPlaca", pci[0].paisPlaca?.codDatacat);
    sessionStorage.setItem("placa", pci[0].nomPlaca);
    sessionStorage.setItem("canalControl", pci[0].tipoControl?.desDataCat);
    sessionStorage.setItem("pci", JSON.stringify(pci[0]));    
    sessionStorage.setItem("funcionario", JSON.stringify(ubicacion)); //DESCOMENTAR
    
    this.router.navigate(['/iaregistrodpmn/datos-transporte']);

  }

  getDataPciSynchronous(numCorrelativo : string) {
    //DESCOMENTAR
     let ubicacionFuncionario = this.registroDpmnService.datosFuncionario;
    let aduana = ubicacionFuncionario.puestoControl.aduana.codigo;
    let puesto = ubicacionFuncionario.puestoControl.codigo;
    console.log("aduana", aduana);
    console.log("puesto", puesto); 
    
    return this.http.get(`${environment.urlBaseIntranet}/v1/controladuanero/scci/pcis/${aduana}-${puesto}/listaparadpmn?numCorrelativo=${numCorrelativo}`).toPromise()
  }


}
