export class CheckDpmn {
  correlativoDpmn: number;
  cntSeriesDcl: number;
  cntArchivosAdjuntos: number;
}
