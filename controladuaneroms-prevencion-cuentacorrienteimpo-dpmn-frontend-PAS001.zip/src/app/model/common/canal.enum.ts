export enum Canal {
  ROJO = "R",
  NARANJA = "N",
  VERDE = "V",
  DOCUMENTARIO = "D",
  FISICO = "F"
}
