import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListarDpmnFuncionarioComponent } from './listar-dpmn-funcionario.component';

describe('ListarDpmnFuncionarioComponent', () => {
  let component: ListarDpmnFuncionarioComponent;
  let fixture: ComponentFixture<ListarDpmnFuncionarioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListarDpmnFuncionarioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListarDpmnFuncionarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
