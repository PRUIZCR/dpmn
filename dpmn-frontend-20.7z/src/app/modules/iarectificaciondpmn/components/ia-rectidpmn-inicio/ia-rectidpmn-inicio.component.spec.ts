import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IaRectidpmnInicioComponent } from './ia-rectidpmn-inicio.component';

describe('IaRectidpmnInicioComponent', () => {
  let component: IaRectidpmnInicioComponent;
  let fixture: ComponentFixture<IaRectidpmnInicioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IaRectidpmnInicioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IaRectidpmnInicioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
