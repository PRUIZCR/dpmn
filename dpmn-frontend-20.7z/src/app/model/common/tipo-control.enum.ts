export enum TipoControl {
  FISICO = "F",
  DOCUMENTARIO = "D"
}
