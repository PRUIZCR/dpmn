import { ChangeDetectorRef, Component, OnInit} from '@angular/core';
import { RectificacionDpmnService } from '../../../../services/rectificacion-dpmn.service';

@Component({
  selector: 'app-it-rectidpmn-inicio',
  templateUrl: './it-rectidpmn-inicio.component.html',
  styleUrls: ['./it-rectidpmn-inicio.component.css']
})
export class ItRectidpmnInicioComponent implements OnInit {

  pasoActual : number = 1;

  constructor(private rectificacionDpmnService: RectificacionDpmnService,
              private cdRef:ChangeDetectorRef) { }

  ngOnInit(): void {
    this.rectificacionDpmnService.pasoActual$.subscribe( (numPaso : number) => {
        this.pasoActual = numPaso;
        this.cdRef.detectChanges();
    });
  }

}
