import { ChangeDetectorRef, Component, OnInit} from '@angular/core';
import { Subscription } from 'rxjs/internal/Subscription';
import { Dpmn } from 'src/app/model/domain/dpmn.model';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { RectificacionDpmnService } from '../../../../services/rectificacion-dpmn.service';

@Component({
  selector: 'app-it-rectidpmn-inicio',
  templateUrl: './it-rectidpmn-inicio.component.html',
  styleUrls: ['./it-rectidpmn-inicio.component.css']
})
export class ItRectidpmnInicioComponent implements OnInit {

  pasoActual : number = 1;
  datosCabeceraDpmnForm!: FormGroup;
  nroDpmn!:string;
  private dataDpmn! : Dpmn;
  private dpmnSubs! : Subscription;
  constructor(private rectificacionDpmnService: RectificacionDpmnService,
    private formBuilder: FormBuilder,
              private cdRef:ChangeDetectorRef) { this.buildForm;}

  ngOnInit(): void {
    this.rectificacionDpmnService.pasoActual$.subscribe( (numPaso : number) => {
        this.pasoActual = numPaso;
        this.cdRef.detectChanges();
        
        });
        this.buildForm();
        this.dpmnSubs = this.rectificacionDpmnService.dpmn$.subscribe((newDpmn : Dpmn) => {
          this.dataDpmn = newDpmn;
          console.log("ngOnInit()-this.dpmnSubs-this.dataDpmn: "+this.dataDpmn);
          this.completarDatosDpmn(this.dataDpmn);
        });
      }
      
      private buildForm() : void {
        this.datosCabeceraDpmnForm = this.formBuilder.group({
          numDpmn: ['', [Validators.required]]
        });
      }
      private completarDatosDpmn(dataDpmn: Dpmn) : void {
        
         this.nroDpmn=dataDpmn.aduana.codDatacat+'-'+dataDpmn.annDpmn+'-'+ this.formatearNumDPMN(dataDpmn.numDpmn);
        console.log("this.nroDpmn: "+this.nroDpmn)
        this.datosCabeceraDpmnForm.get("numDpmn").setValue(this.nroDpmn);
        //this.controlPasoForm.get("numDpmn").setValue(8445854);
        
      }
      formatearNumDPMN(numDpmn: string | null|number){
        if (!numDpmn || numDpmn === '' || numDpmn === 'null' || numDpmn === 'undefined') {
            return '';
        }
        numDpmn =  Array(Math.max(10 - String(numDpmn).length + 1, 0)).join('0') + numDpmn;
    
        return numDpmn;
      }
      get txtNumDpmn() : AbstractControl {
        return this.datosCabeceraDpmnForm.get("numDpmn") as FormControl;
      }

}
