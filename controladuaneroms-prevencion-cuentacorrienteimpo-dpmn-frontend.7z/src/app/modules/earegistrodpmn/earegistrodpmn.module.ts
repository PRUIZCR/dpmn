import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { KeyFilterModule } from 'primeng/keyfilter';
import { ToastModule } from 'primeng/toast';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DialogModule } from 'primeng/dialog';
import { ProgressSpinnerModule } from 'primeng/progressspinner';

import { EaregistrodpmnRoutingModule } from './earegistrodpmn-routing.module';
import { EaNewdpmnInicioComponent } from './components/ea-newdpmn-inicio/ea-newdpmn-inicio.component';
import { EaNewdpmnDatostranspComponent } from './components/ea-newdpmn-datostransp/ea-newdpmn-datostransp.component';
import { EaNewdpmnDatoscompComponent } from './components/ea-newdpmn-datoscomp/ea-newdpmn-datoscomp.component';
import { EaNewdpmnAdddclComponent } from './components/ea-newdpmn-adddcl/ea-newdpmn-adddcl.component';
import { EaNewdpmnAdjuntoComponent } from './components/ea-newdpmn-adjunto/ea-newdpmn-adjunto.component';

import { PuestoControlService } from '../../services/puesto-control.service';
import { UbigeoService } from '../../services/ubigeo.service';
import { RegistroDpmnService } from '../../services/registro-dpmn.service';
import { CatalogoService } from '../../services/catalogo.service';
import { PaisesService } from '../../services/paises.service';

import { SharedModule } from './../../shared/shared.module';

import { APP_ENDPOINT_CONFIG, appEndpointExtranet } from '../../utils/app-endpoint-config';
import { EmpredtiService } from 'src/app/services/empredti.service';
import { EntvehiculoService } from 'src/app/services/entvehiculo.service';

@NgModule({
  declarations: [EaNewdpmnInicioComponent, EaNewdpmnDatostranspComponent, EaNewdpmnDatoscompComponent, EaNewdpmnAdddclComponent, EaNewdpmnAdjuntoComponent],
  imports: [
    SharedModule,
    CommonModule,
    EaregistrodpmnRoutingModule,
    TableModule,
    ButtonModule,
    AutoCompleteModule,
    KeyFilterModule,
    ConfirmDialogModule,
    DialogModule,
    ProgressSpinnerModule,
    ToastModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    PuestoControlService,
    UbigeoService,
    CatalogoService,
    PaisesService,
    EmpredtiService,
    EntvehiculoService,
    RegistroDpmnService, {
      provide: APP_ENDPOINT_CONFIG,
      useValue: appEndpointExtranet
    }
  ]
})
export class EaregistrodpmnModule { }
