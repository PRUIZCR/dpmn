import { Component, OnInit } from '@angular/core';
import { Respuesta } from 'src/app/model/common/Respuesta';
import { TokenAccesoService } from 'src/app/services/token-acceso.service';
import { Estado } from 'src/app/model/common/Estado';
import { ItemDpmnParaAnular } from 'src/app/model/bean/item-dpmn-para-anular.model';
import { BuscarAnularDpmnService } from 'src/app/services/buscar-anular-dpmn.service';
import { BuscarDpmnService } from 'src/app/services/buscar-dpmn.service';
import { MessageService } from 'primeng/api';
import { Router, ActivatedRoute } from '@angular/router';
import { forkJoin, Observable } from 'rxjs';
import { AnulacionDpmnService } from 'src/app/services/anulacion-dpmn.service';

@Component({
  selector: 'app-listar-dpmn',
  templateUrl: './listar-dpmn.component.html',
  styleUrls: ['./listar-dpmn.component.css'],
  providers: [MessageService, BuscarDpmnService]
})
export class ListarDpmnComponent implements OnInit {
  public rptaListaCtrlDpmns: Respuesta<ItemDpmnParaAnular[]> = Respuesta.create(null, null);
  public lstDpmns: any[] = new Array();
  usuarioLogin = this.tokenAccesoService.origen;
  coUsuarioRegistroDPMN : String;
  actorRegistro: String;

  public lstDpmnsSelected: any[] = new Array();
  
  constructor(private buscarAnularDpmnService : BuscarAnularDpmnService,
                private anulacionDpmnService : AnulacionDpmnService,
                private buscarDpmnService: BuscarDpmnService,
                private messageService: MessageService,
                private router:Router,
                private activatedRoute: ActivatedRoute,
                private tokenAccesoService: TokenAccesoService) { }

  ngOnInit(): void {
  }

  anularDpmnSeleccionadas(){
    
  }


  irPageBusquedaInicial() {
		this.buscarAnularDpmnService.limpiarData();
		this.router.navigate(['../buscar-dpmn'], { relativeTo: this.activatedRoute });
  }

}
