import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ItanulaciondpmnRoutingModule } from './itanulaciondpmn-routing.module';
import { BuscarDpmnComponent } from './components/buscar-dpmn/buscar-dpmn.component';
import { ListarDpmnComponent } from './components/listar-dpmn/listar-dpmn.component'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { APP_ENDPOINT_CONFIG, appEndpointInternet } from '../../utils/app-endpoint-config';

import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {AutoCompleteModule} from 'primeng/autocomplete';
import {MessagesModule} from 'primeng/messages';
import {KeyFilterModule} from 'primeng/keyfilter';
import {ToastModule} from 'primeng/toast';
import {DatePipe } from '@angular/common'
import {ConfirmDialogModule } from 'primeng/confirmdialog';
import {DialogModule } from 'primeng/dialog';
import {CalendarModule} from 'primeng/calendar';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import {InputTextModule} from 'primeng/inputtext';
import {DropdownModule} from 'primeng/dropdown';
import {RadioButtonModule } from 'primeng/radiobutton';
import { CatalogoService } from 'src/app/services/catalogo.service';
import { PaisesService } from 'src/app/services/paises.service';
import { UbigeoService } from 'src/app/services/ubigeo.service';
import { PuestoControlService } from 'src/app/services/puesto-control.service';
import { BuscarAnularDpmnService } from 'src/app/services/buscar-anular-dpmn.service';

@NgModule({
    declarations: [
        BuscarDpmnComponent,
        ListarDpmnComponent
    ],
    imports: [ 
        CommonModule,
        ItanulaciondpmnRoutingModule,
        TableModule,
        AutoCompleteModule,
        KeyFilterModule,
        ConfirmDialogModule,
        DialogModule,
        ProgressSpinnerModule,
        InputTextModule,
        ToastModule,
        FormsModule,
        ReactiveFormsModule,
        DropdownModule,
        RadioButtonModule,
        CalendarModule,
        ButtonModule,
    ],
    exports: [
        ButtonModule
    ],
    providers: [
        CatalogoService,
        PaisesService,
        UbigeoService,
        PuestoControlService,
        DatePipe,
        BuscarAnularDpmnService, {
            provide: APP_ENDPOINT_CONFIG,
            useValue: appEndpointInternet
          }
    ],
})
export class ItanulaciondpmnModule {}