import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';

import { BuscarDpmnComponent } from './components/buscar-dpmn/buscar-dpmn.component';
import { ListarDpmnComponent } from './components/listar-dpmn/listar-dpmn.component';

const routes: Routes = [
    { path: 'buscar-dpmn', component: BuscarDpmnComponent },
    { path: 'listar-dpmn-anular', component: ListarDpmnComponent },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ItanulaciondpmnRoutingModule {}
