import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BuscarDpmnFuncionarioComponent } from './components/buscar-dpmn-funcionario/buscar-dpmn-funcionario.component';
import { IaRectidpmnAdddclComponent } from './components/ia-rectidpmn-adddcl/ia-rectidpmn-adddcl.component';
import { IaRectidpmnAdjuntoComponent } from './components/ia-rectidpmn-adjunto/ia-rectidpmn-adjunto.component';
import { IaRectidpmnDatoscompComponent } from './components/ia-rectidpmn-datoscomp/ia-rectidpmn-datoscomp.component';
import { IaRectidpmnDatostranspComponent } from './components/ia-rectidpmn-datostransp/ia-rectidpmn-datostransp.component';
import { IaRectidpmnInicioComponent } from './components/ia-rectidpmn-inicio/ia-rectidpmn-inicio.component';
import { ListarDpmnFuncionarioComponent } from './components/listar-dpmn-funcionario/listar-dpmn-funcionario.component';

const routes: Routes = [
  { path: 'buscar-dpmn', component: BuscarDpmnFuncionarioComponent },
  { path: 'listar-dpmn-recti', component: ListarDpmnFuncionarioComponent },
  {
    path: '', component: IaRectidpmnInicioComponent,
    children: [
      { path: 'datos-transporte', component: IaRectidpmnDatostranspComponent },
      { path: 'comprobantes', component: IaRectidpmnDatoscompComponent },
      { path: 'adjuntar-archivos', component: IaRectidpmnAdjuntoComponent },
      { path: 'add-declaracion', component: IaRectidpmnAdddclComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class IarectificaciondpmnRoutingModule { }
