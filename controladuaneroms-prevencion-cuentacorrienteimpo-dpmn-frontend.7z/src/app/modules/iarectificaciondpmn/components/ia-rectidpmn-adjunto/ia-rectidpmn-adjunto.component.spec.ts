import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IaRectidpmnAdjuntoComponent } from './ia-rectidpmn-adjunto.component';

describe('IaRectidpmnAdjuntoComponent', () => {
  let component: IaRectidpmnAdjuntoComponent;
  let fixture: ComponentFixture<IaRectidpmnAdjuntoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IaRectidpmnAdjuntoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IaRectidpmnAdjuntoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
