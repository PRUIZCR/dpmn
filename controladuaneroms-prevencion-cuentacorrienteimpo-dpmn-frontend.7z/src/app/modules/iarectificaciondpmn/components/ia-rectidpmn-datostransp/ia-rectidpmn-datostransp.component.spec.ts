import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IaRectidpmnDatostranspComponent } from './ia-rectidpmn-datostransp.component';

describe('IaRectidpmnDatostranspComponent', () => {
  let component: IaRectidpmnDatostranspComponent;
  let fixture: ComponentFixture<IaRectidpmnDatostranspComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IaRectidpmnDatostranspComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IaRectidpmnDatostranspComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
