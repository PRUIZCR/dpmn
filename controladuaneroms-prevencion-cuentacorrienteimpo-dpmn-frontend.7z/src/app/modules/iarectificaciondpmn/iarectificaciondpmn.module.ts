import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SharedModule } from './../../shared/shared.module';

import { APP_ENDPOINT_CONFIG, appEndpointIntranet } from '../../utils/app-endpoint-config';

import { CatalogoService } from '../../services/catalogo.service';
import { PaisesService } from '../../services/paises.service';
import { UbigeoService } from '../../services/ubigeo.service';
import { BuscarRectiDpmnService } from '../../services/buscar-recti-dpmn.service';
import { UbicacionFuncionarioService } from '../../services/ubicacion-funcionario.service';
import { RectificacionDpmnService } from '../../services/rectificacion-dpmn.service';
import { PuestoControlService } from '../../services/puesto-control.service';
import { EmpredtiService } from 'src/app/services/empredti.service';
import { EntvehiculoService } from 'src/app/services/entvehiculo.service';
import { DeclaracionService } from 'src/app/services/declaracion.service';
import { BusquedaPciService } from 'src/app/services/busqueda-pci.service';
import { CargaComponentesService } from 'src/app/services/carga-componentes.service';
import { BuscarDpmnService } from 'src/app/services/buscar-dpmn.service';

import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { MessagesModule} from 'primeng/messages';
import { KeyFilterModule } from 'primeng/keyfilter';
import { ToastModule } from 'primeng/toast';
import { DatePipe } from '@angular/common'
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DialogModule } from 'primeng/dialog';
import { CalendarModule} from 'primeng/calendar';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { InputTextModule } from 'primeng/inputtext';
import { DropdownModule} from 'primeng/dropdown';
import { RadioButtonModule } from 'primeng/radiobutton';
import { AccordionModule } from 'primeng/accordion';

import { IarectificaciondpmnRoutingModule } from './iarectificaciondpmn-routing.module';
import { BuscarDpmnFuncionarioComponent } from './components/buscar-dpmn-funcionario/buscar-dpmn-funcionario.component';
import { ListarDpmnFuncionarioComponent } from './components/listar-dpmn-funcionario/listar-dpmn-funcionario.component';
import { IaRectidpmnInicioComponent } from './components/ia-rectidpmn-inicio/ia-rectidpmn-inicio.component';
import { IaRectidpmnDatostranspComponent } from './components/ia-rectidpmn-datostransp/ia-rectidpmn-datostransp.component';
import { IaRectidpmnDatoscompComponent } from './components/ia-rectidpmn-datoscomp/ia-rectidpmn-datoscomp.component';
import { IaRectidpmnAdjuntoComponent } from './components/ia-rectidpmn-adjunto/ia-rectidpmn-adjunto.component';
import { IaRectidpmnAdddclComponent } from './components/ia-rectidpmn-adddcl/ia-rectidpmn-adddcl.component';



@NgModule({
  declarations: [
    BuscarDpmnFuncionarioComponent,
    ListarDpmnFuncionarioComponent,
    IaRectidpmnInicioComponent,
    IaRectidpmnDatostranspComponent,
    IaRectidpmnDatoscompComponent,
    IaRectidpmnAdjuntoComponent,
    IaRectidpmnAdddclComponent],
  imports: [
    SharedModule,
    CommonModule,
    IarectificaciondpmnRoutingModule,
    TableModule,
    ButtonModule,
    AutoCompleteModule,
    KeyFilterModule,
    ConfirmDialogModule,
    DialogModule,
    ProgressSpinnerModule,
    InputTextModule,
    ToastModule,
    FormsModule,
    ReactiveFormsModule,
    DropdownModule,
    RadioButtonModule,
    CalendarModule,
    MessagesModule,
    AccordionModule
  ],
  providers: [
    PuestoControlService,
    UbigeoService,
    CatalogoService,
    PaisesService,
    UbicacionFuncionarioService,
    EmpredtiService,
    EntvehiculoService,
    DeclaracionService,
    BusquedaPciService,
    DatePipe,
    RectificacionDpmnService,
    BuscarRectiDpmnService,
    BuscarDpmnService,
    CargaComponentesService, {
      provide: APP_ENDPOINT_CONFIG,
      useValue: appEndpointIntranet
    }
  ]
})
export class IarectificaciondpmnModule { }
