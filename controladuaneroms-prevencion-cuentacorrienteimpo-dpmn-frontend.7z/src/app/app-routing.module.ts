import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { AccesoExtranetGuard } from './guards/acceso-extranet.guard';

//Lazy Loading de modulos
const routes: Routes = [
  { path: 'itregistrodpmn', loadChildren: () =>
      import('./modules/itregistrodpmn/itregistrodpmn.module').
          then(m => m.ItregistrodpmnModule)},
  { path: 'iaregistrodpmn', loadChildren: () =>
      import('./modules/iaregistrodpmn/iaregistrodpmn.module').
          then(m => m.IaregistrodpmnModule)},
  { path: 'earegistrodpmn', canActivate: [AccesoExtranetGuard],loadChildren: () =>
      import('./modules/earegistrodpmn/earegistrodpmn.module').
          then(m => m.EaregistrodpmnModule)},
  { path: 'itrectificaciondpmn', loadChildren: () =>
      import('./modules/itrectificaciondpmn/itrectificaciondpmn.module').
          then(m => m.ItrectificaciondpmnModule)},
  { path: 'iarectificaciondpmn', loadChildren: () =>
      import('./modules/iarectificaciondpmn/iarectificaciondpmn.module').
          then(m => m.IarectificaciondpmnModule)}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
