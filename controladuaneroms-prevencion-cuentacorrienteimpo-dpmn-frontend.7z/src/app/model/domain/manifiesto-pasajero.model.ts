import { DataCatalogo } from "../common/data-catalogo.model";
import { Auditoria } from "./auditoria.model";
import { Conductor } from "./conductor.model";
import { EmpresaTransporte } from "./empresa-transporte.model";
import { Ubigeo } from "../common/ubigeo.model";

export class ManifiestoPasajero{
    aduana!: DataCatalogo;
    puestoControl!: DataCatalogo;
    annManifiesto!: number;
    numManifiesto!: number;
    regimen!: DataCatalogo;
    ubigeoOrigen!: Ubigeo;
    ubigeoDestino!: Ubigeo;
    cntPasajeros!: number;
    fecSalidaBus!: Date;
    obsManifiesto!: string;
    auditoria!: Auditoria;
    conductor!: Conductor;
    empresaTransporte!: EmpresaTransporte;
}