import { ComprobantePago } from "./comprobante-pago.model";

export class CartaPorte extends ComprobantePago {
  numCartaPorte: string;
  nomEmpresa: string;
}
