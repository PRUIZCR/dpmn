export enum EstadoRuc {
  ACTIVO = "00"
}
