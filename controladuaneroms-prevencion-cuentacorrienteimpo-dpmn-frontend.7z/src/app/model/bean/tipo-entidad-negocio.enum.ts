export enum TipoEntidadNegocio {
    DPMNS = "DPMNS",
    DAM_SERIES_DPMN = "DAM_SERIES_DPMN",
    ADJUNTOS_DPMN = "ADJUNTOS_DPMN"
}
