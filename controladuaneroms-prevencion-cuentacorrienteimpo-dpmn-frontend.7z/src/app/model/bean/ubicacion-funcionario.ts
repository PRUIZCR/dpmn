import { PuestoControlFuncionario } from "./puesto-control-funcionario";
import { MensajeBean } from "../common/MensajeBean";

export class UbicacionFuncionario {

  numeroRegistro: string;
  turno: string;
  servicio: string;
  puestoControl: PuestoControlFuncionario;
  error!: MensajeBean;

}
