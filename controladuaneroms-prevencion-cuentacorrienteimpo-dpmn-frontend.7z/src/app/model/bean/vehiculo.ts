export class Vehiculo {
  cempti: string;
  dplaca: string;
  cestado: string;
  dmarca: string;
  danofab: string;
  dchasis: string;
  msg: string;
}
