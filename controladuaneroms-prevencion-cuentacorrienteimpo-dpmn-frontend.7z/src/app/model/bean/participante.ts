import { DocIdentidad } from '../bean/doc-identidad';

export class Participante {
  docIdentidad: DocIdentidad;
  nombre: string;
}
