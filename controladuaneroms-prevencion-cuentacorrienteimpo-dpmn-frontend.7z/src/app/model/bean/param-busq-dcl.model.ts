export class ParamBusqDcl {
  codAduana: string;
  anio: string;
  codRegimen: string;
  numero: string;
  serie: string;
}
