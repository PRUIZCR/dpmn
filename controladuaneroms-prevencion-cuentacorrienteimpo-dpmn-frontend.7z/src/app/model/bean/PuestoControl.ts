export class PuestoControl {
  codigo: string;
  descripcion: string;
}
