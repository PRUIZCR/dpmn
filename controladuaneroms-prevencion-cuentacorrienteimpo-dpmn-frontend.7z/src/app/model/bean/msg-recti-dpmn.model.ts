import { TipoEntidadNegocio } from "./tipo-entidad-negocio.enum";
import { TipoEvento } from "./tipo-evento.enum";

export class MsgRectiDpmn {
  uuid: string;
  secuencia: number;
  correlativoDpmn: number;
  tipoEvento: TipoEvento;
  jsonPkNegocio: string;
  tipoEntidadNegocio: TipoEntidadNegocio;
  jsonData: string;
  usuario: string;
  version: number;
}
