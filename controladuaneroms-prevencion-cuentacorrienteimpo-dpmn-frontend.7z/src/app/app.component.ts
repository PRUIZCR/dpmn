import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { TokenAccesoService } from './services/token-acceso.service';
import { CargaComponentesService } from './services/carga-componentes.service';
import { UbicacionFuncionarioService } from './services/ubicacion-funcionario.service';
import { RegistroDpmnService } from './services/registro-dpmn.service';
import { UbicacionFuncionario } from './model/bean/ubicacion-funcionario';
import { TokenAccesoExtranetService } from './services/token-acceso-extranet.service';
import { AccesoAnulacionService } from './services/acceso-anulacion.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'controladuaneroms-prevencion-cuentacorrienteimpo-dpmn-frontend';

  constructor(private activateRoute: ActivatedRoute,
    private router: Router,
    private tokenAccesoService: TokenAccesoService,
    private cargaComponentes: CargaComponentesService,
    private ubicacionFuncionarioService: UbicacionFuncionarioService,
private tokenAccesoExtranetService: TokenAccesoExtranetService,
    private accesoAnulacionService: AccesoAnulacionService,
    private registroDpmnService: RegistroDpmnService) { }

  ngOnInit(): void {
    this.activateRoute.queryParams
    .subscribe(params => {
        let hayToken : boolean = params.token != null;
        let hayParamP : boolean = params.p != null;

        if ( hayToken ) {
          this.tokenAccesoService.guardarTokenSession(params.token);
          this.redirectPage(params);
        }

        if(params.modulo === 'earegistrodpmn' && params.login != undefined && params.codemptrans != undefined){
          this.tokenAccesoExtranetService.guardarValorConstante(params);
          this.router.navigate(['/earegistrodpmn/datos-transporte']);
        }

        if ( !hayToken && hayParamP ) {
          this.redirectPage(params);
        }

        if ( params.modulo == 'itrectificaciondpmn' ) {
          this.router.navigate(['/itrectificaciondpmn/buscar-dpmn']);
      }

        if ( params.modulo == 'iarectificaciondpmn' ) {
          this.router.navigate(['/iarectificaciondpmn/buscar-dpmn']);
        }

        if(params.modulo == 'anulaciondpmn' && params.coderig != undefined){
          if(this.accesoAnulacionService.guardarOrigen(params)){
            this.router.navigate(['/anulaciondpmn/buscar-dpmn'], {queryParams: {coderig: params.coderig}});
          }
        }
      }
    );
  }

  private redirectPage(params: any) : void {
    let noHayModulo : boolean = params.modulo == null;

    if ( noHayModulo ) {
      this.router.navigate(['/itregistrodpmn/datos-transporte']);
      return;
    }

    if ( params.modulo == 'itregistrodpmn' ) {      
      this.router.navigate(['/itregistrodpmn/datos-transporte']);      
      return;
    }

    if ( params.modulo == 'iaregistrodpmn' ) {      
      this.router.navigate(['/iaregistrodpmn/listar-control-paso']);
      return;
    }
    if ( params.modulo == 'earegistrodpmn' ) {
      this.router.navigate(['/earegistrodpmn/datos-transporte']);
      return;
    }

    if ( params.modulo == 'iaregistrodpmn_linkeo' ) {      
      //DESCOMENTAR
      this.getDatosFuncionario(params)      
      //this.cargaComponentes.guardarNumCorrePci(params.numCorrePci); //COMENTAR
      //this.cargaComponentes.cargarConfirmacionDeDpmn(null); //COMENTAR      
    }

    if ( params.modulo == 'iaregistrodpmn_linkeo' ) {      
      this.getDatosFuncionario(params);   
  }
  }
  //DESCOMENTAR
   getDatosFuncionario(params: Params){
    let nroRegistro: string = this.tokenAccesoService.nroRegistro as string;

    this.ubicacionFuncionarioService.buscar(nroRegistro).subscribe((ubicacion: UbicacionFuncionario) => {
      if(ubicacion == undefined || ubicacion == null)
        return;

      this.registroDpmnService.datosFuncionario = ubicacion;
      this.cargaComponentes.guardarNumCorrePci(params.numCorrePci);
      this.cargaComponentes.cargarConfirmacionDeDpmn(ubicacion);

    });
  } 

  getCargarRutaRectificacionDpmn(params: Params) {
    let nroRegistro: string = this.tokenAccesoService.nroRegistro as string;

    this.ubicacionFuncionarioService.buscar(nroRegistro).subscribe((ubicacion: UbicacionFuncionario) => {
      if (ubicacion == undefined || ubicacion == null)
        return;

      console.log("ubicacion: ", ubicacion);
      this.registroDpmnService.datosFuncionario = ubicacion;
      this.cargaComponentes.guardarCondicionLinkeo(params.condicionLinkeo);
      this.cargaComponentes.guardarNumCorrePci(params.numCorrePci);
      this.cargaComponentes.guardarDatosRectiDpmn(params.numCorreDpmn);
      this.router.navigate(['/iarectificaciondpmn/datos-transporte']);
    });
  }

}
