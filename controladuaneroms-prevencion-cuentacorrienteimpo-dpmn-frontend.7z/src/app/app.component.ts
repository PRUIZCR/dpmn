import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TokenAccesoService } from './services/token-acceso.service';
import { TokenAccesoExtranetService } from './services/token-acceso-extranet.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'controladuaneroms-prevencion-cuentacorrienteimpo-dpmn-frontend';

  constructor(private activateRoute: ActivatedRoute,
    private router: Router,
    private tokenAccesoService: TokenAccesoService,
    private tokenAccesoExtranetService: TokenAccesoExtranetService,) { }

  ngOnInit(): void {
    this.activateRoute.queryParams
    .subscribe(params => {
        let hayToken : boolean = params.token != null;
        let hayParamP : boolean = params.p != null;

        if ( hayToken ) {
          this.tokenAccesoService.guardarTokenSession(params.token);
          this.redirectPage(params);
        }

        if(params.modulo === 'earegistrodpmn' && params.login != undefined && params.codemptrans != undefined){
          this.tokenAccesoExtranetService.guardarValorConstante(params);
          this.router.navigate(['/earegistrodpmn/datos-transporte']);
        }

        if ( !hayToken && hayParamP ) {
          this.redirectPage(params);
        }

        if ( params.modulo == 'itrectificaciondpmn' ) {
          this.router.navigate(['/itrectificaciondpmn/buscar-dpmn']);
        }

        if ( params.modulo == 'iarectificaciondpmn' ) {
          this.router.navigate(['/iarectificaciondpmn/buscar-dpmn']);
        }
      }
    );
  }

  private redirectPage(params: any) : void {
    let noHayModulo : boolean = params.modulo == null;

    if ( noHayModulo ) {
      this.router.navigate(['/itregistrodpmn/datos-transporte']);
      return;
    }

    if ( params.modulo == 'itregistrodpmn' ) {
      this.router.navigate(['/itregistrodpmn/datos-transporte']);
      return;
    }

    if ( params.modulo == 'iaregistrodpmn' ) {
      this.router.navigate(['/iaregistrodpmn/listar-control-paso']);
    }

    if ( params.modulo == 'earegistrodpmn' ) {
      this.router.navigate(['/earegistrodpmn/datos-transporte']);
    }

  }

}
