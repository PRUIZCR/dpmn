import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { UbicacionFuncionarioService } from './services/ubicacion-funcionario.service';
import { RegistroDpmnService } from './services/registro-dpmn.service';
import { CoreModule } from '../app/core/core.module';
import { DatePipe } from '@angular/common';
import { CargaComponentesService } from './services/carga-componentes.service';
import { appEndpointIntranet, APP_ENDPOINT_CONFIG } from './utils/app-endpoint-config';
import { CatalogoService } from './services/catalogo.service';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    CoreModule
  ],
  providers: [RegistroDpmnService, UbicacionFuncionarioService, CargaComponentesService, DatePipe, CatalogoService, {
    provide: APP_ENDPOINT_CONFIG,
    useValue: appEndpointIntranet
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
