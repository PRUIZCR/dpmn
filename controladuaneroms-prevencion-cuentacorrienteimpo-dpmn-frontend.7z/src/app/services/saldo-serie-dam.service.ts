import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SaldoSerieDam } from '../model/bean/saldo-serie-dam';

import { AppEndpointConfig, APP_ENDPOINT_CONFIG } from '../utils/app-endpoint-config';
import { BehaviorSubject, forkJoin, Observable, of } from 'rxjs';
import { Respuesta } from '../model/common/Respuesta';
import { DamSerieDpmn } from '../model/domain/dam-serie-dpmn.model';
import { Estado } from '../model/common/Estado';
import { ParamBusqDcl } from '../model/bean/param-busq-dcl.model';
import { map } from 'rxjs/operators';

@Injectable()
export class SaldoSerieDamService {

  private rptaValSaldosSerieDam : Respuesta<Boolean>;
  private validacionSaldosSerieDamSubject = new BehaviorSubject<Respuesta<Boolean>>(null);
  public validacionSaldosSerieDam$ = this.validacionSaldosSerieDamSubject.asObservable();

  private cntDamAValidar : number;
  private cntDamValidadas : number;

  constructor(private http: HttpClient, @Inject(APP_ENDPOINT_CONFIG) private  appEndPointConfig : AppEndpointConfig) {}

  buscar(codAduana : string, codRegimen: string, anio: number, numero: number): Observable<SaldoSerieDam[]> {
    let url : string = this.appEndPointConfig.getSaldoCtaCorrienteDam(codAduana, codRegimen, anio, numero);
    return this.http.get<SaldoSerieDam[]>(url);
  }

  validarSaldosDam(damSeriesDpmn : DamSerieDpmn[]): void {

    this.rptaValSaldosSerieDam = Respuesta.create(true, Estado.LOADING);

    this.validacionSaldosSerieDamSubject.next(this.rptaValSaldosSerieDam);

    let dams : DamSerieDpmn[] = this.extraerDamConsultadas(damSeriesDpmn);

    this.cntDamAValidar = dams.length;
    this.cntDamValidadas = 0;

    dams.forEach( ( itemDam : DamSerieDpmn, key: number, arr: Array<DamSerieDpmn> ) => {

      let codAduana : string = itemDam.aduanaDam.codDatacat;
      let codRegimen : string = itemDam.regimenDam.codDatacat;
      let anioDam : number =  itemDam.annDam;
      let numDam : number = itemDam.numDam;

      let esUltimoDam: boolean = (key == arr.length - 1);

      this.buscar(codAduana, codRegimen, anioDam, numDam).
        subscribe( (saldosSerieDam : SaldoSerieDam[]) => {
          let subDamSeriesDpmn : DamSerieDpmn[] = damSeriesDpmn.filter( itemFilter => itemFilter.aduanaDam.codDatacat ==  codAduana &&
                                                                        itemFilter.regimenDam.codDatacat ==  codRegimen &&
                                                                        itemFilter.annDam ==  anioDam &&
                                                                        itemFilter.numDam ==  numDam );

          this.validarDamSeriesDpmnContraSaldos(subDamSeriesDpmn, saldosSerieDam);
          this.cntDamValidadas++;

          //if ( esUltimoDam ) {
          if ( this.cntDamAValidar == this.cntDamValidadas ) {
            this.enviarRptValidacionSaldos();
          }

        }, () => {
          //if ( esUltimoDam ) {
          if ( this.cntDamAValidar == this.cntDamValidadas ) {
            this.enviarRptValidacionSaldos();
          }
        });

    });

  }

  private enviarRptValidacionSaldos() : void {
    let hayMensajes = this.rptaValSaldosSerieDam.mensajes.length > 0;
    this.rptaValSaldosSerieDam.estado = hayMensajes ? Estado.ERROR : Estado.SUCCESS;
    this.validacionSaldosSerieDamSubject.next(this.rptaValSaldosSerieDam);
  }

  private validarDamSeriesDpmnContraSaldos(damSeriesDpmn : DamSerieDpmn[], saldosSerieDam : SaldoSerieDam[]) : void {

    let arraySeries = [];

    damSeriesDpmn.forEach(( damSerieDpmn : DamSerieDpmn ) => {

      let codAduana : string = damSerieDpmn.aduanaDam.codDatacat;
      let codRegimen : string = damSerieDpmn.regimenDam.codDatacat;
      let anioDam : number =  damSerieDpmn.annDam;
      let numDam : number = damSerieDpmn.numDam;
      let numSerie : number = damSerieDpmn.numSerie;
      let cantDeclarada : number = damSerieDpmn.cntUnidadFisica;
      let cntRetirada : number = damSerieDpmn.cntRetirada;

      let numeroCompletoDam  = codAduana + "-" + anioDam + "-" + codRegimen + "-" + numDam;

      let existeIndex = arraySeries.findIndex(x => x.declaracion === numeroCompletoDam && x.numSerie ===  numSerie);

      if(existeIndex != -1){
        let cantidad = arraySeries[existeIndex].cntRetirada + cntRetirada;
        arraySeries[existeIndex].cntRetirada = cantidad;
      }else{
        arraySeries.push({"declaracion": numeroCompletoDam, "numSerie": numSerie, "cntDeclarada" : cantDeclarada, "cntRetirada" : cntRetirada})
      }

    });

    arraySeries.forEach( ( value : any ) => {
      let numeroCompletoDam : string = value.declaracion;
      let cntRetirada : number = value.cntRetirada;
      let numSerie : number = value.numSerie;

      let saldoSerie : SaldoSerieDam = saldosSerieDam.find( saldo => saldo.numSerie == value.numSerie );

      let isSaldoInValido = saldoSerie?.cntSaldo < cntRetirada;

      if ( isSaldoInValido && saldoSerie?.cntSaldo > 0) {
        this.rptaValSaldosSerieDam.agregarMensaje(1, "La cantidad ingresada a retirar excede el saldo disponible de la serie N° " + numSerie + " de la DAM " + numeroCompletoDam);
      }
      if (saldoSerie?.cntSaldo == 0) {
        this.rptaValSaldosSerieDam.agregarMensaje(1, "No existe saldo para la serie N° " + numSerie + " de la DAM " + numeroCompletoDam);
      }

    });

    // damSeriesDpmn.forEach( ( damSerieDpmn : DamSerieDpmn ) => {
    //   console.error(damSerieDpmn);

    //   let codAduana : string = damSerieDpmn.aduanaDam.codDatacat;
    //   let codRegimen : string = damSerieDpmn.regimenDam.codDatacat;
    //   let anioDam : number =  damSerieDpmn.annDam;
    //   let numDam : number = damSerieDpmn.numDam;
    //   let numSerie : number = damSerieDpmn.numSerie;
    //   let cntRetirada : number = damSerieDpmn.cntRetirada;

    //   let numeroCompletoDam  = codAduana + "-" + anioDam + "-" + codRegimen + "-" + numDam;

    //   let saldoSerie : SaldoSerieDam = saldosSerieDam.find( saldo => saldo.numSerie == damSerieDpmn.numSerie );

    //   let isSaldoInValido = saldoSerie?.cntSaldo < cntRetirada;

    //   if ( isSaldoInValido && saldoSerie?.cntSaldo > 0) {
    //     this.rptaValSaldosSerieDam.agregarMensaje(1, "La cantidad ingresada a retirar excede el saldo disponible de la serie N° " + numSerie + " de la DAM " + numeroCompletoDam);
    //   }
    //   if (saldoSerie?.cntSaldo == 0) {
    //     this.rptaValSaldosSerieDam.agregarMensaje(1, "No existe saldo para la serie N° " + numSerie + " de la DAM " + numeroCompletoDam);
    //   }

    // });
  }

  private extraerDamConsultadas (damSeriesDpmn : DamSerieDpmn[]) : DamSerieDpmn[] {

    if ( damSeriesDpmn == null || damSeriesDpmn.length <= 0 ) {
      return new Array();
    }

    let resultado : DamSerieDpmn[] = new Array();

    damSeriesDpmn.forEach( ( item : DamSerieDpmn ) => {

      if ( resultado.length <= 0 ) {
        resultado.push(item);
        return;
      }

      let damSerieDpmnBusq : DamSerieDpmn = resultado.find( itemBusq => itemBusq.aduanaDam.codDatacat == item.aduanaDam.codDatacat &&
                                                          itemBusq.regimenDam.codDatacat == item.regimenDam.codDatacat &&
                                                          itemBusq.annDam == item.annDam &&
                                                          itemBusq.numDam == item.numDam );

      if ( damSerieDpmnBusq == null )  {
        resultado.push(item);
      }

    });

    return resultado;
  }

  /**
   * Completa la informacion de los saldos y secuencia de descarga
   * en las series de la DAM asociadas a una DPMN.
   * @author rcontreras
   * @param damSeriesDpmn Series de la DAM asociadas a una DPMN
   * @returns
   *  Un Observable que emite la info completando los saldos y secuencia de descarga
   */
  completarSaldosDamSerieDpmn( damSeriesDpmn : DamSerieDpmn[] ) : Observable<DamSerieDpmn[]> {

    let damSeriesDpmnSinSaldos : DamSerieDpmn[] = damSeriesDpmn.filter( ( item : DamSerieDpmn ) => item.cntSaldo == null );

    if ( damSeriesDpmnSinSaldos.length <= 0 ) {
      return of(damSeriesDpmn);
    }

    let lstParamsBusq : ParamBusqDcl[] = this.extraerParamBusqDcl(damSeriesDpmnSinSaldos);

    if ( lstParamsBusq.length <= 0 ) {
      return of(damSeriesDpmn);
    }

    let requestSaldosSerieDams : Observable<any>[] = new Array();

    lstParamsBusq.forEach( ( item : ParamBusqDcl ) => {

      let codAduana : string = item.codAduana;
      let codRegimen : string = item.codRegimen;
      let anio: number = Number(item.anio);
      let numero: number = Number(item.numero);

      let url : string = this.appEndPointConfig.getSaldoCtaCorrienteDam(codAduana, codRegimen, anio, numero);

      requestSaldosSerieDams.push(
        this.http.get<any>(url).pipe(map( ( saldos : SaldoSerieDam[] ) => {
          return { "saldos": saldos, "codAduana": codAduana, "codRegimen": codRegimen, "anio": anio, "numero": numero };
        }))
      );

    });

    return forkJoin( requestSaldosSerieDams ).pipe( map( ( resultadosDeSaldos : any[] ) => {
      resultadosDeSaldos.forEach( ( resultadoSaldo : any ) => {

        let saldos : SaldoSerieDam[] = resultadoSaldo.saldos;
        let codAduana : string = resultadoSaldo.codAduana;
        let codRegimen : string = resultadoSaldo.codRegimen;
        let anio: number = resultadoSaldo.anio;
        let numero: number = resultadoSaldo.numero;

        let damSeriesDpmnCompletarSaldos : DamSerieDpmn[] = damSeriesDpmnSinSaldos.filter( ( item : DamSerieDpmn ) => item.aduanaDam.codDatacat == codAduana &&
        item.regimenDam.codDatacat == codRegimen && item.annDam == anio &&  item.numDam == numero);

        damSeriesDpmnCompletarSaldos.forEach( ( item : DamSerieDpmn ) => {

          let saldoSerieDam : SaldoSerieDam = saldos.find( ( itemSaldo : SaldoSerieDam ) => itemSaldo.numSerie == item.numSerie );

          if ( saldoSerieDam != null ) {
            item.cntSaldo = saldoSerieDam.cntSaldo;
            item.numSecDescarga = saldoSerieDam.numSecDescarga;
          }

        });

      });

      damSeriesDpmnSinSaldos.filter( ( item : DamSerieDpmn ) => item.cntSaldo == null ).forEach( ( item : DamSerieDpmn ) => {
        item.cntSaldo = item.cntUnidadFisica;
        item.numSecDescarga = 0;
      });

      return damSeriesDpmn;
    }));

  }


  private extraerParamBusqDcl( newDamSeriesDpmn : DamSerieDpmn[] ) : ParamBusqDcl[] {
    let resultado : ParamBusqDcl[] = new Array();

    newDamSeriesDpmn.forEach( ( item : DamSerieDpmn ) => {
      let existeDcl : boolean = resultado.some( ( itemDcl : ParamBusqDcl ) => itemDcl.anio ==  String(item.annDam) &&
                                                    itemDcl.codAduana == item.aduanaDam.codDatacat &&
                                                    itemDcl.codRegimen == item.regimenDam.codDatacat &&
                                                    itemDcl.numero == String(item.numDam)
                                                     );

      if ( !existeDcl ) {
        let paramBusqDcl : ParamBusqDcl = new ParamBusqDcl();
        paramBusqDcl.anio = String(item.annDam);
        paramBusqDcl.codAduana = item.aduanaDam.codDatacat;
        paramBusqDcl.codRegimen = item.regimenDam.codDatacat;
        paramBusqDcl.numero = String(item.numDam);

        resultado.push(paramBusqDcl);
      }

    });

    return resultado;
  }

}
