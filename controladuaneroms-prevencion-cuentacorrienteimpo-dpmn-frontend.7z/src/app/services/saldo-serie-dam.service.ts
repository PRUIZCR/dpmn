import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SaldoSerieDam } from '../model/bean/saldo-serie-dam';

import { AppEndpointConfig, APP_ENDPOINT_CONFIG } from '../utils/app-endpoint-config';
import { BehaviorSubject, Observable } from 'rxjs';
import { Respuesta } from '../model/common/Respuesta';
import { DamSerieDpmn } from '../model/domain/dam-serie-dpmn.model';
import { Estado } from '../model/common/Estado';

@Injectable()
export class SaldoSerieDamService {

  private rptaValSaldosSerieDam : Respuesta<Boolean>;
  private validacionSaldosSerieDamSubject = new BehaviorSubject<Respuesta<Boolean>>(null);
  public validacionSaldosSerieDam$ = this.validacionSaldosSerieDamSubject.asObservable();

  private cntDamAValidar : number;
  private cntDamValidadas : number;

  constructor(private http: HttpClient, @Inject(APP_ENDPOINT_CONFIG) private  appEndPointConfig : AppEndpointConfig) {}

  buscar(codAduana : string, codRegimen: string, anio: number, numero: number): Observable<SaldoSerieDam[]> {
    let url : string = this.appEndPointConfig.getSaldoCtaCorrienteDam(codAduana, codRegimen, anio, numero);
    return this.http.get<SaldoSerieDam[]>(url);
  }

  validarSaldosDam(damSeriesDpmn : DamSerieDpmn[]): void {

    this.rptaValSaldosSerieDam = Respuesta.create(true, Estado.LOADING);

    this.validacionSaldosSerieDamSubject.next(this.rptaValSaldosSerieDam);

    let dams : DamSerieDpmn[] = this.extraerDamConsultadas(damSeriesDpmn);

    this.cntDamAValidar = dams.length;
    this.cntDamValidadas = 0;

    dams.forEach( ( itemDam : DamSerieDpmn, key: number, arr: Array<DamSerieDpmn> ) => {

      let codAduana : string = itemDam.aduanaDam.codDatacat;
      let codRegimen : string = itemDam.regimenDam.codDatacat;
      let anioDam : number =  itemDam.annDam;
      let numDam : number = itemDam.numDam;

      let esUltimoDam: boolean = (key == arr.length - 1);

      this.buscar(codAduana, codRegimen, anioDam, numDam).
        subscribe( (saldosSerieDam : SaldoSerieDam[]) => {
          let subDamSeriesDpmn : DamSerieDpmn[] = damSeriesDpmn.filter( itemFilter => itemFilter.aduanaDam.codDatacat ==  codAduana &&
                                                                        itemFilter.regimenDam.codDatacat ==  codRegimen &&
                                                                        itemFilter.annDam ==  anioDam &&
                                                                        itemFilter.numDam ==  numDam );

          this.validarDamSeriesDpmnContraSaldos(subDamSeriesDpmn, saldosSerieDam);
          this.cntDamValidadas++;

          //if ( esUltimoDam ) {
          if ( this.cntDamAValidar == this.cntDamValidadas ) {
            this.enviarRptValidacionSaldos();
          }

        }, () => {
          //if ( esUltimoDam ) {
          if ( this.cntDamAValidar == this.cntDamValidadas ) {
            this.enviarRptValidacionSaldos();
          }
        });

    });

  }

  private enviarRptValidacionSaldos() : void {
    let hayMensajes = this.rptaValSaldosSerieDam.mensajes.length > 0;
    this.rptaValSaldosSerieDam.estado = hayMensajes ? Estado.ERROR : Estado.SUCCESS;
    this.validacionSaldosSerieDamSubject.next(this.rptaValSaldosSerieDam);
  }

  private validarDamSeriesDpmnContraSaldos(damSeriesDpmn : DamSerieDpmn[], saldosSerieDam : SaldoSerieDam[]) : void {

    damSeriesDpmn.forEach( ( damSerieDpmn : DamSerieDpmn ) => {

      let codAduana : string = damSerieDpmn.aduanaDam.codDatacat;
      let codRegimen : string = damSerieDpmn.regimenDam.codDatacat;
      let anioDam : number =  damSerieDpmn.annDam;
      let numDam : number = damSerieDpmn.numDam;
      let numSerie : number = damSerieDpmn.numSerie;
      let cntRetirada : number = damSerieDpmn.cntRetirada;

      let numeroCompletoDam  = codAduana + "-" + anioDam + "-" + codRegimen + "-" + numDam;

      let saldoSerie : SaldoSerieDam = saldosSerieDam.find( saldo => saldo.numSerie == damSerieDpmn.numSerie );

      let isSaldoInValido = saldoSerie?.cntSaldo < cntRetirada;

      if ( isSaldoInValido && saldoSerie?.cntSaldo > 0) {
        this.rptaValSaldosSerieDam.agregarMensaje(1, "La cantidad ingresada a retirar excede el saldo disponible de la serie N° " + numSerie + " de la DAM " + numeroCompletoDam);
      }
      if (saldoSerie?.cntSaldo == 0) {
        this.rptaValSaldosSerieDam.agregarMensaje(1, "No existe saldo para la serie N° " + numSerie + " de la DAM " + numeroCompletoDam);
      }

    });



  }

  private extraerDamConsultadas (damSeriesDpmn : DamSerieDpmn[]) : DamSerieDpmn[] {

    if ( damSeriesDpmn == null || damSeriesDpmn.length <= 0 ) {
      return new Array();
    }

    let resultado : DamSerieDpmn[] = new Array();

    damSeriesDpmn.forEach( ( item : DamSerieDpmn ) => {

      if ( resultado.length <= 0 ) {
        resultado.push(item);
        return;
      }

      let damSerieDpmnBusq : DamSerieDpmn = resultado.find( itemBusq => itemBusq.aduanaDam.codDatacat == item.aduanaDam.codDatacat &&
                                                          itemBusq.regimenDam.codDatacat == item.regimenDam.codDatacat &&
                                                          itemBusq.annDam == item.annDam &&
                                                          itemBusq.numDam == item.numDam );

      if ( damSerieDpmnBusq == null )  {
        resultado.push(item);
      }

    });

    return resultado;
  }

}
