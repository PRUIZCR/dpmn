import { Injectable } from '@angular/core';
import { ConstantesApp }  from '../utils/constantes-app';
import { environment }  from '../../environments/environment';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Respuesta } from '../model/common/Respuesta';
import { Estado } from '../model/common/Estado';
import { map, catchError, shareReplay, tap } from 'rxjs/operators';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { TokenAccesoService }from '../services/token-acceso.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' }),
};

@Injectable({
  providedIn: 'root'
})
export class TokenAccesoExtranetService {

  private rptaBusqDclSource = new BehaviorSubject<Respuesta<any>>(null);

  public rptaBusqDcl$ = this.rptaBusqDclSource.asObservable();

  constructor(private http: HttpClient,
            private tokenService: TokenAccesoService) { }

  obtenerUrlToken(): Observable<any>{
   return this.getUrlEndpointToken();
  } 

  private getUrlEndpointToken(): Observable<any>{

    this.rptaBusqDclSource.next(Respuesta.create(null, Estado.LOADING));

    const params = new HttpParams()
          .set('grant_type', 'client_credentials')
          .set('scope', ConstantesApp.SCOPE_EXTRANET)
          .set('client_id', ConstantesApp.CLIENT_ID_EXTRANET)
          .set('client_secret', ConstantesApp.CLIENT_SECRET_EXTRANET);

    return this.http.post<any>(environment.urlApiSeguridad + "/v1/clientesextranet/591606e2-e796-4b69-b76a-1692b7bddd02/oauth2/token/",
          params.toString(),
          httpOptions )
          .pipe(

            tap(data => {
              Respuesta.create(null, Estado.SUCCESS);
              this.tokenService.guardarTokenSession(data.access_token);
              //this.guardarValorContante();
            }),

            catchError((error: HttpErrorResponse) => {
              console.error(error);
              this.removerValorConstante();
              this.rptaBusqDclSource.next(Respuesta.createFromErrorHttp(error));
              return throwError(error);
            })
          );
    // return environment.urlApiSeguridad + "/v1/clientesextranet/" + ConstantesApp.CLIENT_ID_EXTRANET + "/oauth2/token/"
  }


  guardarValorConstante(params: any): void {
    sessionStorage.setItem(ConstantesApp.KEY_SESSION_LOGIN, params.login);
    sessionStorage.setItem(ConstantesApp.KEY_SESSION_ORIGEN, ConstantesApp.ORIGEN_EXTRANET);
    sessionStorage.setItem(ConstantesApp.KEY_SESSION_COD_EMPTRANS, params.codemptrans);
  }

  removerValorConstante(): void {
    sessionStorage.removeItem(ConstantesApp.KEY_SESSION_LOGIN);
    sessionStorage.removeItem(ConstantesApp.KEY_SESSION_ORIGEN);
    sessionStorage.setIteremoveItemm(ConstantesApp.KEY_SESSION_COD_EMPTRANS);
  }

}
