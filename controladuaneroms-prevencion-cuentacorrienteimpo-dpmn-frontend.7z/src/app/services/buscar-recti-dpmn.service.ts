import { Inject, Injectable } from '@angular/core';
import { BehaviorSubject, EMPTY, Observable, of, throwError } from 'rxjs';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

import { Respuesta } from '../model/common/Respuesta';
import { Estado } from '../model/common/Estado';
import { DataCatalogo } from '../model/common/data-catalogo.model';
import { ParamBusqDpmnParaRectificar } from '../model/bean/param-busq-dpmn-rectificar.model';
import { ItemDpmnParaRectificar } from '../model/bean/item-dpmn-para-rectificar.model';

import { map, catchError } from 'rxjs/operators';
import { AppEndpointConfig, APP_ENDPOINT_CONFIG } from '../utils/app-endpoint-config';
import { Auditoria } from '../model/domain/auditoria.model';

/**
 * Servicio para la busqueda de DPMN que pueden ser rectificadas
 */
@Injectable()
export class BuscarRectiDpmnService {

  private URL_RESOURCE_BUSQUEDA_DPMN : string;

  private rptaBusqDclSource = new BehaviorSubject<Respuesta<ItemDpmnParaRectificar[]>>(null);

  public rptaBusqDcl$ = this.rptaBusqDclSource.asObservable();
 
  public rptaListaCtrlDpmns: ItemDpmnParaRectificar[] ;

  public itemDpmn: ItemDpmnParaRectificar = new ItemDpmnParaRectificar();

  constructor(private http: HttpClient,
             @Inject(APP_ENDPOINT_CONFIG) private appEndPointConfig : AppEndpointConfig) {
             this.URL_RESOURCE_BUSQUEDA_DPMN = appEndPointConfig.buscarParaRectificar;
  }
  
  buscarParaRectificar( paramBusqDpmnRecti : ParamBusqDpmnParaRectificar ) : void {
    
    this.rptaBusqDclSource.next(Respuesta.create(null, Estado.LOADING));

    this.validarDpmnsHttp(paramBusqDpmnRecti).subscribe((respuesta : Respuesta<ItemDpmnParaRectificar[]>) => {
      this.rptaBusqDclSource.next(respuesta);
      this.rptaListaCtrlDpmns = respuesta.data;
    });

  };

  private validarDpmnsHttp( paramBusqDpmnRecti : ParamBusqDpmnParaRectificar ): Observable<Respuesta<ItemDpmnParaRectificar[]>> {
    return this.http.post<any>(this.URL_RESOURCE_BUSQUEDA_DPMN, paramBusqDpmnRecti).pipe(
          map( ( dpmns : ItemDpmnParaRectificar[])=> {

            if ( dpmns == null ) {
              return Respuesta.create(null, Estado.SUCCESS);
            }

        return Respuesta.create(dpmns, Estado.SUCCESS);
      }),
      catchError((error: HttpErrorResponse) => {
        console.error(error);
        this.rptaBusqDclSource.next(Respuesta.createFromErrorHttp(error));
        return throwError(error);
        })
    );
  }

  limpiarData() : void {
		this.itemDpmn = new  ItemDpmnParaRectificar();
    this.rptaBusqDclSource.next(Respuesta.create(null, null));
	}
}
