import { Inject, Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { BehaviorSubject, Observable, throwError } from 'rxjs';

import { Respuesta } from '../model/common/Respuesta';
import { Estado } from '../model/common/Estado';
import { ItemDpmnParaAnular } from '../model/bean/item-dpmn-para-anular.model';

import { map, catchError } from 'rxjs/operators';
import { ParamBusqDpmnParaAnular } from "../model/bean/param-busq-dpmn-anular.model";
import { AppEndpointConfig, APP_ENDPOINT_CONFIG } from '../utils/app-endpoint-config';

/**
 * Servicio para la busqueda de DPMN que pueden ser anuladas manualmente
 */
@Injectable()
export class BuscarAnularDpmnService {
  private URL_RESOURCE_BUSQUEDA_DPMN : string;

  private rptaBusqDclSource = new BehaviorSubject<Respuesta<ItemDpmnParaAnular[]>>(null);

  public rptaBusqDcl$ = this.rptaBusqDclSource.asObservable();

  public rptaListaCtrlDpmns: ItemDpmnParaAnular[] ;

  public itemDpmn: ItemDpmnParaAnular = new ItemDpmnParaAnular();


  constructor(private http: HttpClient,
    @Inject(APP_ENDPOINT_CONFIG) private appEndPointConfig : AppEndpointConfig) {
      this.URL_RESOURCE_BUSQUEDA_DPMN = appEndPointConfig.buscarParaAnular;
  }


  buscarParaAnular( paramBusqDpmnParaAnular : ParamBusqDpmnParaAnular  ) : void {
        
    this.rptaBusqDclSource.next(Respuesta.create(null, Estado.LOADING));

    this.rptaBusqDclSource.next(Respuesta.create(null, Estado.LOADING));

    this.validarDpmnsHttp(paramBusqDpmnParaAnular).subscribe((respuesta : Respuesta<ItemDpmnParaAnular[]>) => {
      this.rptaBusqDclSource.next(respuesta);
      this.rptaListaCtrlDpmns = respuesta.data;
    });
  };

  private validarDpmnsHttp( paramBusqDpmnParaAnular : ParamBusqDpmnParaAnular ): Observable<Respuesta<ItemDpmnParaAnular[]>> {
    return this.http.post<any>(this.URL_RESOURCE_BUSQUEDA_DPMN, paramBusqDpmnParaAnular).pipe(
          map( ( dpmns : ItemDpmnParaAnular[])=> {

            if ( dpmns == null ) {
              return Respuesta.create(null, Estado.SUCCESS);
            }

        return Respuesta.create(dpmns, Estado.SUCCESS);
      }),
      catchError((error: HttpErrorResponse) => {
        console.error(error);
        this.rptaBusqDclSource.next(Respuesta.createFromErrorHttp(error));
        return throwError(error);
        })
    );
  }

  limpiarData() : void {
		this.itemDpmn = new  ItemDpmnParaAnular();
    this.rptaBusqDclSource.next(Respuesta.create(null, null));
	}
}