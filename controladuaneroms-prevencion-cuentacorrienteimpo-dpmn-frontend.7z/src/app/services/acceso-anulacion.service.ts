import { Injectable } from '@angular/core';
import { ConstantesApp }  from '../utils/constantes-app';

@Injectable({
    providedIn: 'root'
})

export class AccesoAnulacionService {

    private origen = [ 
        ConstantesApp.ORIGEN_INTERNET,
        ConstantesApp.ORIGEN_EXTRANET
    ];
    
    guardarOrigen(params: any): boolean {
        sessionStorage.setItem(ConstantesApp.KEY_SESSION_ORIGEN, params.coderig);
        if(sessionStorage.getItem(ConstantesApp.KEY_SESSION_ORIGEN) !== null && this.origen.includes(params.coderig)) 
            return true;
        return false;
    }

}