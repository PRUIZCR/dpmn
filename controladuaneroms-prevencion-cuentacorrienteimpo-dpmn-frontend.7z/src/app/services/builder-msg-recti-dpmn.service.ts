import { Injectable } from '@angular/core';
import {Dpmn} from '../model/domain/dpmn.model';
import { MsgRectiDpmn } from '../model/bean/msg-recti-dpmn.model';

@Injectable()
export class BuilderMsgRectiDpmnService<T> {

  constructor() { }

  build( dataOriginal: T, dataRectificada: T ) :  MsgRectiDpmn[] {
    return null;
  }



}
