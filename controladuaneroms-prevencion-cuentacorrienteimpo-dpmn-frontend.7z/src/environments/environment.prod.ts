export const environment = {
  production: true,
  urlBase: 'https://api.sunat.gob.pe',
  urlBaseIntranet: 'https://api-intranet.sunat.peru',
  urlComponentPCI: 'http://localhost:4400',
  urlIntegradorComponentPCI: '../pci'
};
