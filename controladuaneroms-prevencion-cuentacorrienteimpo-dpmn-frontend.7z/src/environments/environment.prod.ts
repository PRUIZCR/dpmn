export const environment = {
  production: true,
  urlBase: 'https://api.sunat.gob.pe',
  urlBaseIntranet: 'https://api-intranet.sunat.peru',
  urlApiSeguridad: 'https://api-seguridad.sunat.gob.pe',
  urlComponentPCI: '../pci',
  urlIntegradorComponentPCI: '../pci'
};
