export const environment = {
  production: false,
  urlBase: 'https://api-test.sunat.gob.pe',
  urlBaseIntranet: 'https://api-intranet.sunat.peru',
  urlApiSeguridad: 'https://api-seguridad-test.sunat.gob.pe',
  urlComponentPCI: '../pci',
  urlIntegradorComponentPCI: '../pci'
};
