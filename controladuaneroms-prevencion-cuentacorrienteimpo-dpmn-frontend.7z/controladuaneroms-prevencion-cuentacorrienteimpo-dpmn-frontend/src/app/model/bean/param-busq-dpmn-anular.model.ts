import { ParamBusqPlacaVehiculo } from "./param-busq-placa-vehiculo.model";
import { ParamBusqDocumento } from "./param-busq-documento";
import { ParamBusqRangoFecha } from "./param-busq-rango-fecha.model";
import { ParamBusqDcl } from './param-busq-dcl.model';

export class ParamBusqDpmnParaAnular {
    rucRemitente: string;
    placaVehiculo: ParamBusqPlacaVehiculo;
    documento: ParamBusqDocumento;
    declaracion: ParamBusqDcl;
    rangoFechaRegistro: ParamBusqRangoFecha;  
}