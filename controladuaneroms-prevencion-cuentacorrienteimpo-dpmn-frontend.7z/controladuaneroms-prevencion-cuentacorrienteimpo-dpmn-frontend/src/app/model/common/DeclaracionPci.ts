import {DataCatalogo} from './data-catalogo.model';

export class DeclaracionPci {
    aduanaDam : DataCatalogo;
    regimenDam : DataCatalogo;
    annDam : number;
    numDam : number;
}