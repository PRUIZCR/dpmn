import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EaNewdpmnAdddclComponent } from './components/ea-newdpmn-adddcl/ea-newdpmn-adddcl.component';
import { EaNewdpmnAdjuntoComponent } from './components/ea-newdpmn-adjunto/ea-newdpmn-adjunto.component';
import { EaNewdpmnDatoscompComponent } from './components/ea-newdpmn-datoscomp/ea-newdpmn-datoscomp.component';
import { EaNewdpmnDatostranspComponent } from './components/ea-newdpmn-datostransp/ea-newdpmn-datostransp.component';
import { EaNewdpmnInicioComponent } from './components/ea-newdpmn-inicio/ea-newdpmn-inicio.component';

const routes: Routes = [
  {
    path: '', component: EaNewdpmnInicioComponent,
    children: [
      { path: 'datos-transporte', component: EaNewdpmnDatostranspComponent },
      { path: 'comprobantes', component: EaNewdpmnDatoscompComponent },
      { path: 'adjuntar-archivos', component: EaNewdpmnAdjuntoComponent },
      { path: 'add-declaracion', component: EaNewdpmnAdddclComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EaregistrodpmnRoutingModule { }
